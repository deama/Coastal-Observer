var latConvert = 110722.9;
var lngConvert = 111318.32;


function start()
{
	importScripts("jsts.min.js");
}

onmessage = function(data)
{
	if( data.data.type == "intersect" )
	{
		this.postMessage( {type: "intersect", data: intersect( data.data.WKTs,
						  data.data.data[0], data.data.data[1] ) } );
	}
};
			
			




function intersect( WKTs, name1, name2 )
{
	var check = "none";
	
	var wktReader = new jsts.io.WKTReader();

	//ships
	var geom1 = wktReader.read(WKTs[0]);
	var geom2 = wktReader.read(WKTs[1]);
	
	//collision lines
	var geom3 = wktReader.read(WKTs[2]);
	var geom4 = wktReader.read(WKTs[3]);
	
	if( geom1.intersects(geom2) ){ check = "ship"; }
	
	if( check == "none" )
	{
		if( geom3.intersects(geom4) ||
			geom3.intersects(geom2) ||
			geom1.intersects(geom4) ){ check = "line"; }
	}
	
	return [check, name1, name2];
}

//starting function
start();