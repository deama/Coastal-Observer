//array for markers 
var markers = [];
//var clear = false;

function mod(n) 
{
	return ((n%360)+360)%360;
}

function toggleUpdateAnimation()
{		
	if( document.getElementById("toggle").style.backgroundColor == "white" )
	{
		document.getElementById("toggle").style.backgroundColor = "#212121";
		toggleUpdate = false;
	}
	else
	{
		document.getElementById("toggle").style.backgroundColor = "white";
		toggleUpdate = true;
	}
}

var addListenersOnPolygon = function(polygon) 
{
	google.maps.event.addListener(polygon, 'click', function (event) 
	{
		var LAT = undefined;
		var LNG = undefined;
		var checksum = false;
		
		if( this.ship != undefined )
		{
			LAT = this.ship.getPath().getAt(0).lat();
			LNG = this.ship.getPath().getAt(0).lng();
			
			//console.log(this.ship.rateOfTurn);
			
			if( this.ship.checksum ){checksum = "True";}
			else{checksum = "False";}
			
			updateTable( this.ship.name, LAT, LNG, this.ship.rot, this.ship.speed,
						 this.ship.sizeW, this.ship.sizeH, checksum, this.ship.status );
			
			clearPath(this.ship);
			generatePath(this.ship, 0, 0);
			generateFuturePath(this.ship,0,0);
			
			selectionCircle.setCenter( this.ship.getPath().getAt(0) );
			selectionCircle.shipName = this.ship.name;
		}
		else
		{
			LAT = this.getPath().getAt(0).lat();
			LNG = this.getPath().getAt(0).lng();
			
			//console.log(this.rateOfTurn);
			
			if( this.checksum ){checksum = "True";}
			else{checksum = "False";}
			
			updateTable( this.name, LAT, LNG, this.rot, this.speed,
						 this.sizeW, this.sizeH, checksum, this.status );
			
			clearPath(this);
			generatePath(this, 0, 0);
			generateFuturePath(this,0,0); 
			
			selectionCircle.setCenter( this.getPath().getAt(0) );
			selectionCircle.shipName = this.name;
		}
	});
}

function selectionCircle( ship )
{
	circle.setMap(map);
}

//adds markers to ship location 
function addMarker(ship)
{
	var marker = new google.maps.Marker(
	{
		position: ship.getPath().getAt(0),
		map: map,
		label: "U",
		ship: ship
	});

	markers.push(marker);
	return marker;
}

// Sets the map on all markers in the array.
function setMapOnAll(map) 
{
	for( var i = 0; i < markers.length; i++ ) 
	{
		markers[i].setMap(map);
	}
}

var markerListener = function()
{
	var MMSI = this.ship.name; 
	
	var LAT = this.ship.getPath().getAt(0).lat();
	var LNG = this.ship.getPath().getAt(0).lng();
	
	var ROT = this.ship.rot;
	var SPEED = this.ship.speed;

	var SIZEW = this.ship.sizeW;
	var SIZEH = this.ship.sizeH;
	
	var CHECKSUM = this.ship.checksum;
	var STATUS = this.ship.status;
	
	var path = 0;
	var futurePath = 0;
	
	if( CHECKSUM ){CHECKSUM = "True";}
	else{CHECKSUM = "False";}
	
	updateTable( MMSI, LAT, LNG, ROT, SPEED, SIZEW, SIZEH, CHECKSUM, STATUS );
	
	clearPath(this.ship);
	generatePath(this.ship, 0, 0);
	generateFuturePath(this.ship, 0, 0);
	
	selectionCircle.setCenter( this.ship.getPath().getAt(0) );
	selectionCircle.shipName = this.ship.name;
};

function updateTable( MMSI, LAT, LNG, ROT, SPEED, SIZEW, SIZEH, CHECKSUM, STATUS )
{
	document.getElementById("table_MMSI").innerHTML = MMSI;
	document.getElementById("table_Latitude").innerHTML = LAT.toFixed(5);
	document.getElementById("table_Longitude").innerHTML = LNG.toFixed(5);
	document.getElementById("table_TrueHeading").innerHTML = mod(ROT.toFixed(0)-90);
	document.getElementById("table_Speed").innerHTML = SPEED.toFixed(2);
	document.getElementById("table_Size").innerHTML = SIZEW + " x " + SIZEH;
	document.getElementById("table_Checksum").innerHTML = CHECKSUM;
	document.getElementById("table_Status").innerHTML = STATUS;
	document.getElementById("table_pastpath").innerHTML = 
		"<line style='color: #6D7D7D; background-color: #6D7D7D; font-size: 0.5vh;'> ___________________________________________ </line>";
	document.getElementById("table_futurepath").innerHTML = 
		"<line2 style='color:red; background-color: red; font-size: 0.5vh;'> ___________________________________________ </line2>";
}


//move markers and change labels 
function moveMarker(marker)
{
	//marker.set("label", state[0]);
	marker.setPosition( marker.ship.getPath().getAt(0) );
};

function centerMap()
{
	map.setZoom(11),
	map.setCenter({
		lat : 51.04,
		lng : 1.70
	});
}
	
// Removes the markers from the map, but keeps them in the array.
//	function clearMarkers() 
//	{
//		setMapOnAll(null);
//		clear = true;			
//	}

// Shows any markers currently in the array.
//	function showMarkers()
//	{
//		setMapOnAll(map);
//		clear = false;
//	}





//11.94333074

//1.15283
//6.91698 mp/6m
//1.15283 miles = 0.0144571346 lng
//6.917 miles = 0.0867428076 lng

//68.8 miles = 1 degree of latitude = 110722.9 meters
//69.17 miles = 1 degree of longitude = 111318.32 meters
//69.17 mph = 60 knots/h
//1.15283 mph = 1 nautical mile an hour (knot)

//1.15283333333 mpm = 1 knots/m
//0.01921388888 mps = 0.01666666666 knots/s
//111318 meters per second = 216385 knots/s
//1 knot/s = 0.00000462139 longitude
//0.00066666666
var latConvert = 110722.9;
var lngConvert = 111318.32;
var toMiles = 1.1583;
var toLng = 0.0144571346;

var map = null;

var shipHolder = [];
var colHolder = [];
var shipPaths = [];

var linePath = 0;
var lineFuturePath = 0;
var selectionCircle = 0;

var toggleUpdate = false;

var worker_intersect = new Worker("javascripts/worker_intersect.js");

//"ws://" +document.domain+ "/ship-tracking/communicate"
var webSocket = new WebSocket("ws://zanidrak.com/ship-tracking/communicate");


function initMap()
{
	map = new google.maps.Map(document.getElementById("map"),
	{
		zoom: 11,
		center: {lat: 51.04, lng: 1.70},
		disableDoubleClickZoom: true,
		streetViewControl: false,
		mapTypeId: "OSM",
		scaleControl: false,
		disableDefaultUI: true,
		
		styles: 
		[
			{
				"featureType": "all",
				"stylers": [ {"visibility": "off"} ]
			}
		]
	});
	
	map.mapTypes.set("OSM", new google.maps.ImageMapType(
	{
		getTileUrl: function(coord, zoom)
		{
			var tilesPerGlobe = 1 << zoom;
			var x = coord.x % tilesPerGlobe;
			if (x < 0) 
			{
				x = tilesPerGlobe+x;
			}
			return "http://tile.openstreetmap.org/" + zoom + "/" + x + "/" + coord.y + ".png";
		},
		tileSize: new google.maps.Size(256, 256),
		name: "OpenStreetMap",
		maxZoom: 18
	}));
	
	//wait for DOM to finish loading first, then continue...
	setTimeout( function()
	{ 
		cont(); 
	}, 1000 );
}

function cont()
{
	linePath = new google.maps.Polyline(
	{
		path: [],
		geodesic: true,
		strokeColor: "#000000",
		strokeOpacity: 0.4,
		strokeWeight: 3
	});
	linePath.setMap(map);
	
	lineFuturePath = new google.maps.Polyline(
	{
		path: [],
		geodesic: true,
		strokeColor: "red",
		strokeOpacity: 0.4,
		strokeWeight: 3
	});
	lineFuturePath.setMap(map);
	
	selectionCircle = new google.maps.Circle(
	{
		strokeColor: 'white',
		strokeOpacity: 0.6,
		strokeWeight: 3,
		fillColor: 'white',
		fillOpacity: 0.3,
		map: map,
		center: undefined,
		radius: 100,
		zIndex: -2,
		shipName: undefined
	});
	selectionCircle.setMap(map);
	
	//11.94333074

	//1.15283
	//6.91698 mp/6m
	//1.15283 miles = 0.0144571346 lng
	//6.917 miles = 0.0867428076 lng
	
	//68.8 miles = 1 degree of latitude = 110722.9 meters
	//69.17 miles = 1 degree of longitude = 111318.32 meters
	//69.17 mph = 60 knots/h
	//1.15283 mph = 1 nautical mile an hour (knot)
	
	//1.15283333333 mpm = 1 knots/m
	//0.01921388888 mps = 0.01666666666 knots/s
	//111318 meters per second = 216385 knots/s
	//1 knot/s = 0.00000462139 longitude
	//0.00066666666
	//toMiles = 1.1583;
	//toLng = 0.0144571346;
	//edge = originLng - ( (speed/12) *toMiles *toLng );
	//1.47480 - ( (10/12) *1.1583 *0.0144571346)
	//1.46084525
	//addShip(originLat, originLng, sizeW, sizeH, rot, speed, name, positions, status, checksum, future)
//	var positions =
//	[
//		50.97500, 1.72800,
//		50.97400, 1.72900,
//		50.97300, 1.73000,
//		50.97200, 1.73100,
//		50.97100, 1.73200
//	]
//	var future =
//	[
//		50.97500, 1.72800,
//		50.97550, 1.72900,
//		50.97600, 1.73000,
//		50.97650, 1.73100,
//		50.97700, 1.73200,
//		50.97750, 1.73300,
//		50.97800, 1.73400
//	]
//	
//	addShip( 50.98017, 1.72017, 200, 40, 70, 3, 2434216, [], "Using anchor", true, [] );
//	addShip( 50.98100, 1.72400, 200, 40, 20, 6, 766, [], "Using anchor", true, [] );
//	
//	addShip( 50.97500, 1.71980, 200, 40, 90, 1, 966, [], "Thing", true, [] );
//	addShip( 50.97500, 1.72000, 200, 40, 40, 3, 866, [], "Thing", true, [] );
//	
//	addShip( 50.97500, 1.72800, 200, 40, 60, 4, 2434211, positions, "Under way using engine", true, future );
//	
//	var updateCircle = new google.maps.Circle(
//	{
//		strokeColor: '#FF0000',
//		strokeOpacity: 0.6,
//		strokeWeight: 3,
//		fillColor: '#FF0000',
//		fillOpacity: 0,
//		map: map,
//		center: undefined,
//		radius: 200,
//		zIndex: -2
//	});
//	updateCircle.setMap(map);
//	updateCircle.setCenter( shipHolder[1].getPath().getAt(0) );
	
//	setTimeout( function()
//	{
//		for( var i = 0; i < shipHolder.length; i++ )
//		{
//			if( shipHolder[i].name == "666" )
//			{
//				//         lat,     lng,    rot,spd, ship,         col...
//				posUpdate( 50.98117, 1.72017, 450, 10, shipHolder[i], colHolder[i],
//						   true, "idk", 10 );
//				break;
//			}
//		}
//	}, 6000 );
//	setTimeout( function()
//	{
//		for( var i = 0; i < shipHolder.length; i++ )
//		{
//			if( shipHolder[i].name == "666" )
//			{
//				//         lat,     lng,    rot,spd, ship,         col...
//				posUpdate( 50.98117, 1.72017, 20, 10, shipHolder[i], colHolder[i],
//						   true, "idk", 5 );
//				break;
//			}
//		}
//	}, 13000 );
	
	//4:44:15 PM
	//4:46:41 PM
	
	
			
	//First is rate of turn, 
	//second is speed over ground, 
	//third is course over ground,
	//final is true heading
	//document.domain + "/ship-tracking/getGridUpdate"
	$.get("http://zanidrak.com/ship-tracking/getGridUpdate",
	function(data)
	{			
		$.each( data, function(name, field)
		{
			if( field.Position.length > 0 )
			{
				addShip( field.Position[0], field.Position[1], 200, 40,
						 field.Movement[3], field.Movement[1], name, field.Position, 
						 field.Statistics.Status, field.Statistics.Checksum, field.Prediction );
			}
		})
	},"json");
	
	webSocket.onclose = function(data)
	{
		console.log("Connection closed: " + data); 
	};
	
	
	//232001470
	setTimeout( function()
	{
		//Waiting for requests to create/update ships from websocket
		webSocket.onmessage = function(data)
		{ 
			if( data.data == "RESET" )
			{
				for( var i = 0; i < shipHolder.length; i++ )
				{
					shipHolder[i].state = "Remove";
							
					fade(shipHolder[i]);
					fade(colHolder[i]);
					fade(shipHolder[i].rotationLine);
					
					shipHOlder[i].marker.setMap(null);
					
					shipHolder.splice( i, 1 );
					colHolder.splice( i, 1 );
					markers.splice( i, 1 );						
				}
				console.log( "CLEARING ALL SHIPS" );
			}
			else
			{
				$.each( JSON.parse(data.data), function(name, field)
				{
					var ship = null;
					var col = null;
					for( var i = 0; i < shipHolder.length; i++ )
					{
						if( shipHolder[i].name == name && field.Val == "Remove" )
						{			
							shipHolder[i].state = "Remove";
							
							fade(shipHolder[i]);
							fade(colHolder[i]);
							fade(shipHolder[i].rotationLine);
							
							shipHolder[i].marker.setMap(null);
							
							shipHolder.splice( i, 1 );
							colHolder.splice( i, 1 );
							markers.splice( i, 1 );
							
							console.log("!!!!!!!!!!REMOVING: " + name);
							break;
						}
						
						if( shipHolder[i].name == name )
						{
							ship = shipHolder[i];
							col = colHolder[i];
							break;
						}
					}
					
					if( ship != null )
					{
						if( field.Position != undefined )
						{
							posUpdate( field.Position[0], field.Position[1],
								field.Movement[3], field.Movement[1], ship, col, 
								field.Statistics.Checksum, field.Statistics.Status, field.Movement[0], field.Prediction );
								
							appendPosition( field.Position[1], field.Position[0], ship );
						}
					}
					else
					{
						if( field.Position != undefined )
						{
							addShip( field.Position[0], field.Position[1], 200, 40, field.Movement[3], field.Movement[1], 
									 name, field.Position, field.Statistics.Status, field.Statistics.Checksum, field.Prediction );
						}
					}
				})
			}
		};
	}, 400 );
	setInterval( function()
	{
		document.getElementById("shipCounter").innerHTML = shipHolder.length;
	}, 2000 );
}







function toWKT( poly )
{
	return new Wkt.Wkt().fromObject(poly).write();
}
	
function posUpdate( updateLat, updateLng, updateRot, updateSpeed, 
					ship, col, checksum, status, rateOfTurn, prediction )
{			
	var path = [];
	var edge = 0;			
	ship.future = prediction;
	updateRot = updateRot%360;
	
	
	if( rateOfTurn == 0 )
	{
		rateOfTurn = 4;
		
	//	var point1 = new google.maps.LatLng( ship.getPath().getAt(0).lat().toFixed(5), 
	//										 ship.getPath().getAt(0).lng().toFixed(5) );
	//	var point2 = new google.maps.LatLng( updateLat, updateLng );
	//	
	//	updateRot = google.maps.geometry.spherical.computeHeading( point1, point2 )+90;
	}
	if( rateOfTurn < 0 ){rateOfTurn = rateOfTurn*(0-1);}
	if( rateOfTurn == 127 ){rateOfTurn = 6;}
	if( rateOfTurn == -128 ){rateOfTurn = 6;}
	
	
	
	var turnDiff = updateRot - ship.rot;
	if( turnDiff < 0 ){ if( 0-rateOfTurn*5.6 > turnDiff ){updateRot = ship.rot-rateOfTurn*5.6;} }
	else{ if( !(rateOfTurn*5.6 > turnDiff) ){updateRot = ship.rot+rateOfTurn*5.6;} }
	
	
	var drawColLine = false;
	
	var div = 12;
	var latDiff = ( updateLat - ship.getPath().getAt(0).lat().toFixed(5) ) / div;
	var lngDiff = ( updateLng - ship.getPath().getAt(0).lng().toFixed(5) ) / div;
	var speedDiff = (updateSpeed - ship.speed) / div;
	var rotDiff = (updateRot - ship.rot) / div;
	
	var originLat = ship.getPath().getAt(0).lat();
	var originLng = ship.getPath().getAt(0).lng();
	
	ship.checksum = checksum;
	ship.status = status;			
	ship.rateOfTurn = rateOfTurn;

	var rotationLinePath = [];
	
	ship.rotationLine.start = ship.getPath().getAt(3);
	
	ship.rotationLine.prevRot = ship.rot;
	ship.rotationLine.rot = updateRot;
	
	
	if( toggleUpdate )
	{
		ship.updateCircle.setOptions( { strokeOpacity: 0.7 } );
		ship.updateCircle.setCenter( ship.getPath().getAt(0) );
		setTimeout( function()
		{
			fadeUpdateCircle(ship);
		}, 100);
	}
	
	
	move( originLat, originLng, ship, col, path, edge, speedDiff,
		  latDiff, lngDiff, rotDiff, 0, div, rotationLinePath, 0, drawColLine )
	
}

function fadeUpdateCircle( ship )
{
	ship.updateCircle.setOptions( { strokeOpacity: ship.updateCircle.strokeOpacity-0.03 } );
	
	
	
	if( ship.updateCircle.strokeOpacity < 0 )
	{
		ship.updateCircle.setOptions( { strokeOpacity: 0 } );
		return;
	}
	
	setTimeout( function()
	{ 
		fadeUpdateCircle(ship);
	}, 50 );
}





function colShipUpdate(ship, col, i, WKTs)
{		
	if( ship.updated )
	{
		i = 0;
		ship.updated = false;
	}
	
	if( ship.intersected )
	{
		if( ship.marker.getMap() == null )
		{
			ship.marker.setMap(map);
		}
	}
	else
	{
		if( ship.marker.getMap() != null )
		{
			ship.marker.setMap(null);
		}
	}
	
		
	if( !shipHolder[i] )//if null do this...
	{
		i = 0;
		ship.intersected = false;
	}
	else //if not null do this...
	{
		if( ship.name != shipHolder[i].name )
		{
			WKTs[0] = toWKT( ship );
			WKTs[1] = toWKT( shipHolder[i] );
			
			WKTs[2] = toWKT( col );
			WKTs[3] = toWKT( colHolder[i] );
				
				
			worker_intersect.postMessage( {type: "intersect", data:	[ship.name, shipHolder[i].name],
				WKTs: [WKTs[0], WKTs[1], WKTs[2], WKTs[3]] } );
				
			////////////////////////////////////////////////
			worker_intersect.onmessage = function(e)
			{
				if( e.data.type == "intersect" )
				{
					for( var i = 0; i < shipHolder.length; i++ )
					{
						if( e.data.data[1] == shipHolder[i].name )
						{
							if( e.data.data[0] == "ship" )
							{
								if( shipHolder[i].status != "Moored" && shipHolder[i].status != "Using anchor" )
								{
									shipHolder[i].intersected = true;
									shipHolder[i].updated = true;
									
									shipHolder[i].marker.set("label", "C");
								}
							}
							if( e.data.data[0] == "line" )
							{
								shipHolder[i].intersected = true;
								shipHolder[i].updated = true;
								
								shipHolder[i].marker.set("label", "M");
							}
						}
					}
				}
			};
			////////////////////////////////////////////////
		}
		i++;
	}
	
	if( ship.state != "Remove" )
	{
		setTimeout( function()
		{ 
			colShipUpdate(ship, col, i, WKTs); 
		}, 50 );
	}
}


function clearPath(ship)
{
	for( var i = 0; i < shipHolder.length; i++ )
	{
		shipHolder[i].clicked = false;
		if( shipHolder[i].name == ship.name )
		{			
			ship.clicked = true;
		}
	}
}

function generatePath( ship, path, i )
{
	if( ship.clicked )
	{
		path = [];
		for( i = ship.positions.length-2; i >= 0; i=i-2 )
		{
			path.push( {lat: ship.positions[i], lng: ship.positions[i+1] } );
		}
		
		linePath.setPath(path);
	
	
		setTimeout( function()
		{ 
			generatePath( ship, path, i );
		}, 300 );
	}
}
function generateFuturePath( ship, pathFuture, i )
{
	if( ship.clicked )
	{
		pathFuture = [];				
		for( i = 0; i <= ship.future.length-2; i=i+2 )
		{
			pathFuture.push( {lat: ship.future[i], lng: ship.future[i+1] } );
		}
		
		lineFuturePath.setPath(pathFuture);
	
	
		setTimeout( function()
		{ 
			generateFuturePath( ship, pathFuture, i );
		}, 300 );
	}
}
function appendPosition( lat, lng, ship )
{
	var newPositions = [lng, lat];
	newPositions = newPositions.concat(ship.positions);
	
	ship.positions = newPositions;
}




//



function move( currentLat, currentLng, ship, col, path, edge, speedDiff,
			   latDiff, lngDiff, rotDiff, i, div, rotationLinePath, s, drawColLine )
{			
	currentLat = currentLat + latDiff;
	currentLng = currentLng + lngDiff;
	ship.speed = ship.speed + speedDiff;
	ship.rot = ship.rot + rotDiff;
	
	edge = currentLng - ( (ship.speed/12) *toMiles *toLng );
	
	path =  
		[						
			{lat: currentLat, lng: currentLng},
			{lat: currentLat + ( (ship.sizeH/2) / latConvert ), lng: currentLng + ( (ship.sizeW/2) / lngConvert ) },
			{lat: currentLat + ( (ship.sizeH/2) / latConvert ), lng: currentLng },
			{lat: currentLat, lng: currentLng - ( (ship.sizeW/2) / lngConvert ) },
			{lat: currentLat - ( (ship.sizeH/2) / latConvert ), lng: currentLng },
			{lat: currentLat - ( (ship.sizeH/2) / latConvert ), lng: currentLng + ( (ship.sizeW/2) / lngConvert ) }
		];
	ship.setPath(path);
	
	path =
		[
			{lat: currentLat, lng: currentLng},
			{lat: currentLat + ( (ship.sizeH/6) / latConvert ), lng: currentLng },
			{lat: currentLat + ( (ship.sizeH/6) / latConvert ), lng: edge },
			{lat: currentLat - ( (ship.sizeH/6) / latConvert ), lng: edge },
			{lat: currentLat - ( (ship.sizeH/6) / latConvert ), lng: currentLng }
		];
	col.setPath(path);
		
	moveMarker(ship.marker);
	
	if( selectionCircle.shipName == ship.name )
	{
		selectionCircle.setCenter( ship.getPath().getAt(0) );
	}
		
	
	rotatePolygon( ship, ship.rot );
	rotatePolygon( col, ship.rot );
	generateRotation( rotationLinePath, currentLat, currentLng, ship, s, rotDiff, i, path, col );
	
	if( !drawColLine ){col.setMap(null);}
	else{ship.rotationLine.setMap(null);}
	
	
	
	
	if( ship.name == document.getElementById("table_MMSI").innerHTML )
	{
		updateTable( ship.name, currentLat, currentLng, ship.rot, ship.speed, 
					 ship.sizeW, ship.sizeH, ship.checksum, ship.status );
	}
	
	
	if( i >= div-1 )
	{
		ship.rotationLine.setMap(null);
		col.setMap(map);
		return;
	}
	i++;
	
	setTimeout( function()
	{
		move( currentLat, currentLng, ship, col, path, edge, speedDiff,
			  latDiff, lngDiff, rotDiff, i, div, rotationLinePath, s, drawColLine )
	}, 50 );
}

function generateRotation( rotationLinePath, currentLat, currentLng, ship, s, rotDiff, i, path, col )
{
	rotationLinePath = 
	[						
		{lat: currentLat, lng: currentLng},
		col.getPath().getAt(3)
		//ship.getPath().getAt(3)
	];
	ship.rotationLine.setPath(rotationLinePath);
	
	path = 
	[
		{lat: currentLat, lng: currentLng},
		col.getPath().getAt(3)
		//ship.getPath().getAt(3)
	];
	if( rotDiff > 0 )
	{
		for( s = 1; s <= (ship.rotationLine.rot-ship.rotationLine.prevRot)-rotDiff*(i+1); s++ )
		{
			rotatePolygon( ship.rotationLine, s );
			
			path.push( ship.rotationLine.getPath().getAt(1) );
			ship.rotationLine.setPath(rotationLinePath);
		}
	}
	else if( rotDiff < 0 )
	{
		for( s = 1; s <= (ship.rotationLine.prevRot-ship.rotationLine.rot)+rotDiff*(i+1); s++ )
		{
			rotatePolygon( ship.rotationLine, 0-s );
			
			path.push( ship.rotationLine.getPath().getAt(1) );
			ship.rotationLine.setPath(rotationLinePath);
		}
	}
	
	ship.rotationLine.setPath(path);
	ship.rotationLine.setMap(map);
}


function fade(poly)
{					
	if( poly.fillOpacity != 0 )
	{
		poly.setOptions( { fillOpacity: poly.fillOpacity-0.003,
			strokeWeight: poly.strokeWeight-0.022 } );
	}
	else
	{
		poly.setOptions( { strokeWeight: poly.strokeWeight-0.022 } );
	}
		
	
	if( poly.strokeWeight <= 0 )
	{
		if( poly.marker != null ){ poly.marker.setMap(null); }
		poly.setMap(null);
		return;
	}
	
	setTimeout( function()
	{
		fade(poly);
	}, 50 );
}

function fadeCircle(circle)
{
	circle.setOptions( { strokeWeight: circle.strokeWeight-0.2 } );
		
	
	if( circle.strokeWeight <= 0 )
	{
		circle.setMap(null);
		return;
	}
	
	setTimeout( function()
	{
		fade(circle);
	}, 1 );
}

function fadePath(path)
{
	path.setOptions( { strokeWeight: path.strokeWeight-0.02 } );
		
	
	if( path.strokeWeight <= 0 )
	{
		if( path.marker != null ){ path.marker.setMap(null); }
		path.setMap(null);
		return;
	}
	
	setTimeout( function()
	{
		fade(path);
	}, 50 );
}


function rotatePolygon( polygon, angle )
{			
	var prj = map.getProjection();
	var origin = prj.fromLatLngToPoint( polygon.getPath().getAt(0) ); //rotate around first point

	var coords = polygon.getPath().getArray().map( function(latLng)
	{
		var point = prj.fromLatLngToPoint(latLng);
		var rotatedLatLng =  prj.fromPointToLatLng( rotatePoint(point,origin,angle) );
		var data = {lat: rotatedLatLng.lat(), lng: rotatedLatLng.lng()};
		return data;
	});
	polygon.setPath(coords);
}

function rotatePoint( point, origin, angle )
{
	var angleRad = angle * Math.PI / 180.0;
	var rot = 
	{
		x: Math.cos(angleRad) * (point.x - origin.x) - Math.sin(angleRad) * (point.y - origin.y) + origin.x,
		y: Math.sin(angleRad) * (point.x - origin.x) + Math.cos(angleRad) * (point.y - origin.y) + origin.y
	};
	return rot;
}


function getAngle( lat1, lng1, lat2, lng2 )
{

	var lngDiff = lng2 - lng1;

	var y = Math.sin(lngDiff) * Math.cos(lat2);
	var x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) *
			Math.cos(lat2) * Math.cos(lngDiff);

	var angle = Math.atan2(y, x);

	angle = Math.toDegrees(angle);
	angle = (angle + 360) % 360;
	angle = 360 - angle;

	return angle;
}


//adds a ship and it's collision line
function addShip(originLat, originLng, sizeW, sizeH, rot, speed, name, positions, status, checksum, future)
{					
	//divide speed by 12 to get per 5 minutes instead of per hour.
	//Times by toMiles to get miles, 
	//then times by toLng to get longitude coverage in that timespan (5 mins)
	var edge = originLng - ( (speed/12) *toMiles *toLng );
	
//	if( future == undefined )
//	{
//		console.log( future );
//	}
	
	
	//drawing ship
	var s = new google.maps.Polygon
	({
		paths:
		[						
			{lat: originLat, lng: originLng},
			{lat: originLat + ( (sizeH/2) / latConvert ), lng: originLng + ( (sizeW/2) / lngConvert ) },
			{lat: originLat + ( (sizeH/2) / latConvert ), lng: originLng },
			{lat: originLat, lng: originLng - ( (sizeW/2) / lngConvert ) },
			{lat: originLat - ( (sizeH/2) / latConvert ), lng: originLng },
			{lat: originLat - ( (sizeH/2) / latConvert ), lng: originLng + ( (sizeW/2) / lngConvert ) }
		],
		strokeColor: "#FF0000",
		strokeOpacity: 0.5,
		strokeWeight: 2,
		fillColor: "#FF0000",
		fillOpacity: 1,
		speed: speed,
		rot: rot%360,
		sizeW: sizeW,
		sizeH: sizeH,
		name: name,
		state: "N",
		type: "ship",
		marker: undefined,
		intersected: false,
		updated: false,
		checksum: checksum,
		status: status,
		positions: positions,
		clicked: false,
		rotationLine: undefined,
		rateOfTurn: 0,
		future: future,
		updateCircle: undefined
	});
	shipHolder.push(s);
	s.setMap(map);
	rotatePolygon( s, rot );
	
	s.marker = addMarker(s);
	s.marker.addListener( "click", markerListener );
	s.marker.setMap(null);
	
	
	//drawing collision rectangle
	var c = new google.maps.Polygon
	({
		paths: 
		[						
			{lat: originLat, lng: originLng},
			{lat: originLat + ( (sizeH/6) / latConvert ), lng: originLng },
			{lat: originLat + ( (sizeH/6) / latConvert ), lng: edge },
			{lat: originLat - ( (sizeH/6) / latConvert ), lng: edge },
			{lat: originLat - ( (sizeH/6) / latConvert ), lng: originLng }
		],
		strokeColor: "#0000FF",
		strokeOpacity: 0.4,
		strokeWeight: 2,
		fillColor: "#0000FF",
		fillOpacity: 0.4, 
		name: name,
		state: "Normal",
		type: "line",
		zIndex: -1,
		ship: s
	});
	colHolder.push(c);
	c.setMap(map);
	rotatePolygon( c, rot );
	
	//drawing collision rotation prediction
	var cr = new google.maps.Polygon
	({
		paths: [],
		strokeColor: "#0000FF",
		strokeOpacity: 0.4,
		strokeWeight: 2,
		fillColor: "#0000FF",
		fillOpacity: 0.4, 
		name: name,
		state: "Normal",
		type: "line",
		zIndex: -1,
		ship: s,
		rot: rot%360,
		start: undefined,
		prevRot: 0
	});
	s.rotationLine = cr;
	
	
	
	var updateCircle = new google.maps.Circle(
	{
		strokeColor: '#FF0000',
		strokeOpacity: 0.6,
		strokeWeight: 3,
		fillColor: '#FF0000',
		fillOpacity: 0,
		map: map,
		center: undefined,
		radius: 200,
		zIndex: -2
	});
	updateCircle.setMap(map);
	s.updateCircle = updateCircle;
	
	
	
	//Initialise before so there is no memory bloat in colShipUpdate()
	//because of recursion
	var shipWKT1 = toWKT(s);
	var shipWKT2 = toWKT(s);
	
	var colWKT1 = toWKT(s);
	var colWKT2 = toWKT(s);
	
	addListenersOnPolygon(s);
	addListenersOnPolygon(c);
	addListenersOnPolygon(cr);
	
	//Create a thread that detects collision for this ship
	setTimeout( function()
	{
		colShipUpdate( s, c, 0, [shipWKT1, shipWKT2, colWKT1, colWKT2] );
	}, 500 );
}