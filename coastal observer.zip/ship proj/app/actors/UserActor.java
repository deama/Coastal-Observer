package actors;

import akka.actor.ActorRef;
import akka.actor.Props;
import akka.actor.UntypedActor;
import com.fasterxml.jackson.databind.JsonNode;

/**
 * Created by mr450 on 13/11/2016.
 *
 */
public class UserActor extends UntypedActor {

    private final String identifier;
    private final ActorRef output;

    public static Props props(String identifier, ActorRef output) {
        return Props.create(UserActor.class, identifier, output);
    }

    public UserActor(String identifier, ActorRef output) {
        this.identifier = identifier;
        this.output = output;
    }

    @Override
    public void onReceive(Object msg) throws Throwable {
        if(msg instanceof JsonNode) {
            output.tell(msg, self());
        }
    }
}
