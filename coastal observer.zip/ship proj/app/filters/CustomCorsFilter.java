package filters;

import akka.stream.Materializer;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executor;
import java.util.function.Function;
import javax.inject.*;
import play.mvc.*;
import play.mvc.Http.RequestHeader;


/**
 * Created by mr450 on 31/10/2016.
 *
 */
@Singleton
public class CustomCorsFilter extends Filter {

    private final Executor exec;

    @Inject
    public CustomCorsFilter(Materializer mat, Executor exec) {
        super(mat);
        this.exec = exec;
    }

    @Override
    public CompletionStage<Result> apply(Function<RequestHeader, CompletionStage<Result>> next,
        RequestHeader request_header) {
            return next.apply(request_header).thenApplyAsync(result ->
                result.withHeaders(
                    "Access-Control-Allow-Origin", "*",
                    "Access-Control-Allow-Methods", "GET, OPTIONS",
                    "Access-Control-Allow-Headers", "*",
                    "Access-Control-Max-Age", "86400"), exec);
    }
}
