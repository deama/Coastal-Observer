import javax.inject.*;
import play.*;
import play.mvc.EssentialFilter;
import play.http.HttpFilters;

import filters.CustomCorsFilter;

@Singleton
public class Filters implements HttpFilters {

    private final Environment env;
    private final EssentialFilter cors_filter;

    @Inject
    public Filters(Environment env, CustomCorsFilter custom_cors) {
        this.env = env;
        this.cors_filter = custom_cors;
    }

    @Override
    public EssentialFilter[] filters() {
        if (env.mode().equals(Mode.DEV)) {
            return new EssentialFilter[] { cors_filter };
        } else {
            return new EssentialFilter[] { };
        }
    }
}
