package models;

/**
 * Created by mr450 on 28/11/2016.
 *
 */
class UnusableMovement extends Movement {
    UnusableMovement(byte rate_of_turn, double speed_over_ground, double course_over_ground, short true_heading) {
        super(rate_of_turn, speed_over_ground, course_over_ground, true_heading);
    }
}
