package models;

/**
 * Created by mr450 on 28/11/2016.
 *
 */
class UnusablePosition extends Position {
    UnusablePosition(double longitude, double latitude, boolean position_accuracy) {
        super(longitude, latitude, position_accuracy);
    }
}
