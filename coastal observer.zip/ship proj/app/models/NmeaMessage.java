package models;

import static models.AISMessageType.*;

/**
 * Created by mr450 on 31/10/16.
 *
 * An AIS NMEA message created using a data source.
 *
 * For specification details on AIS refer to
 * https://www.itu.int/dms_pubrec/itu-r/rec/m/R-REC-M.1371-5-201402-I!!PDF-E.pdf
 */
public class NmeaMessage {
    enum State {
        OK,             // Message is valid and data was read
        CORRUPTED,      // Message is invalid or data could not be read
        NOT_SUPPORTED,  // Message is not yet supported by the system
        NOT_SET         // For multi-part messages where null would otherwise be needed
    }

    enum Dependency {
        NONE,           // This is a single payload message
        PRECEDING,      // This message is the next message in a chain of messages
        SUCCEEDING,     // This message is the previous message in a chain of messages
        BOTH            // This message is not a starting message and it is not an ending message.
                        // Only used in multi-part messages with a size of 3 or greater
    }

    // This message replaces the need for null
    private static final NmeaMessage default_message = new NmeaMessage(State.NOT_SET);
    // This message is returned for badly broken messages
    private static final NmeaMessage corrupt_message = new NmeaMessage(State.CORRUPTED);
    private static final AISMessageType[] cached_types = AISMessageType.values();
    private static final AISNavigationState[] caches_navs = AISNavigationState.values();

    // These fields are for when a payload consists of multiple messages
    private NmeaMessage preceding_message;
    private NmeaMessage succeeding_message;

    // Message attributes
    private String payload;
    private int frag_index;
    private int frag_count;
    private boolean checksum_valid;
    private State message_integrity;
    private Dependency message_dependency;
    private boolean is_cnb;

    // Payload content
    private AISMessageType type; // 6 bits
    //private byte repeat_indicator; // 2 bits
    private int mmsi; // 30 bits
    private AISNavigationState nav_state; // 4 bits
    private byte rate_of_turn; // 8 bits
    private double speed_over_ground; // 10 bits
    private boolean position_accuracy; // 1 bit
    private double longitude; // 28 bits
    private double latitude; // 27 bits
    private double course_over_ground; // 12 bits
    private short true_heading; // 9 bits
    private byte utc_seconds; // 6 bits
    private byte maneuver_indicator; // 2 bits
    private byte spare; // 3 bits
    //private boolean raim_flag; // 1 bit
    private int radio_state; // 19 bits

    /**
     * @return A "default" AIS message. Used to
     * represent an empty or non-existent message.
     */
    static NmeaMessage defaultNmeaMessage() {
        return default_message;
    }

    /**
     * @return A "corrupt" AIS message. Used to
     * represent blatantly broken (missing fields, broken payload,
     * incorrect fragment values and more) messages. Messages that
     * fail during the payload read do not use this singleton message
     */
    private static NmeaMessage corruptNmeaMessage() { return corrupt_message; }

    /**
     * Constructs a new {@link NmeaMessage} object and returns it otherwise
     * if the new object has an error {@link State} then the default
     * {@link NmeaMessage} object.
      *
     * @param payload The ASCII AIS NMEA payload.
     * @param frag_count The number of messages for a multi-message transmission.
     * @param frag_index The index of the message in a multi-message transmission.
     * @param checksum_valid State if the NMEA message successfully matched its checksum.
     * @return A new {@link NmeaMessage} object or the default {@link NmeaMessage} object
     */
    static NmeaMessage create(String payload, int frag_count, int frag_index, boolean checksum_valid) {
        NmeaMessage message = new NmeaMessage(payload, frag_count, frag_index, checksum_valid);

        if(message.getIntegrity() != State.CORRUPTED) {
            return message;
        } else {
            return corruptNmeaMessage();
        }
    }

    /**
     * Instantiate an {@link NmeaMessage} with valid AIS NMEA data.
     * If the data is not valid or not supported then message's {@link State}
     * will be set to an error value
     *
     * @param payload The ASCII AIS NMEA payload.
     * @param frag_count The number of messages for a multi-message transmission.
     * @param frag_index The index of the message in a multi-message transmission.
     * @param checksum_valid State if the NMEA message successfully matched its checksum.
     */
    private NmeaMessage(String payload, int frag_count, int frag_index, boolean checksum_valid) {
        this.payload = payload;
        this.frag_count = frag_count;
        this.frag_index = frag_index;
        this.checksum_valid = checksum_valid;

        if(frag_count == 0 || frag_index == 0 || frag_index > frag_count || payload.length() == 0) {
            message_integrity = State.CORRUPTED;
            return;
        }

        if(frag_index == 1 && frag_count == 1) {
            message_dependency = Dependency.NONE;
        } else if(frag_index == 1 && frag_count > 1) {
            message_dependency = Dependency.SUCCEEDING;
        } else if(frag_index == frag_count && frag_count > 1) {
            message_dependency = Dependency.PRECEDING;
        } else if(frag_index != 1 && frag_index != frag_count) {
            message_dependency = Dependency.BOTH;
        }

        preceding_message = defaultNmeaMessage();
        succeeding_message = defaultNmeaMessage();

        readPayload();
    }

    /**
     * Set the {@link State} of the message directly.
     *
     * @param state The state of the new message.
     */
    private NmeaMessage(State state) {
        payload = "";
        frag_count = 0;
        frag_index = 0;
        checksum_valid = false;
        message_integrity = state;
        nav_state = AISNavigationState.UNKNOWN;
        message_dependency = Dependency.NONE;
        is_cnb = false;
    }

    /**
     * Read the ASCII AIS NMEA payload and instantiate
     * relevant fields using the data given. Basic data
     * validation occurs and the message's {@link State}
     * may be altered to an error value.
     */
    private void readPayload() {
        int length = payload.length(); // Character length
        byte[] data = payload.getBytes();

        // Size in bits. The data is encoded as 6 bits each stored
        // in a byte so we subtract 2 bits for every byte
        int payload_length = (data.length * 8) - (2 * data.length);

        // The payload is ASCII-encoded
        for(int index = 0; index < length; index++) {
            int letter = (payload.charAt(index) - '0');

            if(letter > 40) {
                letter = letter - 8;
            }

            data[index] = (byte)letter;
        }

        // Start as valid initially
        message_integrity = State.OK;

        // This tells us what type of data is inside the
        // message payload; the AIS message type
        int type_int = (data[0] & 0b00111111) - 1;

        // Make sure it is a valid enum ordinal
        if(type_int < cached_types.length && type_int >= 0) {
            type = cached_types[type_int];
        } else {
            type = AISMessageType.UNKNOWN;
        }

        // Common Navigation block (CNB)
        is_cnb = (type == POS_REPORT_A || type == POS_REPORT_A_ASSIGNED || type == POS_REPORT_A_RESPONSE);

        if(is_cnb && frag_index == 1) {
            // We assume corruption if the payload is not 168 bits long
            if(payload_length != 168) {
                message_integrity = State.CORRUPTED;
                return;
            }

            // The first two bits in a byte are not used therefore we use
            // bitmasking and shifting to bitwise the values together
            // for all fields

            // 2 bits
            //repeat_indicator = (byte)(data[1] & 0b00110000);

            // Maritime Mobile Service Identity (MMSI) consists of 30 bits
            mmsi = mmsi | ((data[1] & 0b00001111) << 2) << 6; // 4 bits
            mmsi = (mmsi | (data[2] << 2)) << 6; // 6 bits
            mmsi = (mmsi | (data[3] << 2)) << 6; // 6 bits
            mmsi = (mmsi | (data[4] << 2)) << 6; // 6 bits
            mmsi = (mmsi | (data[5] << 2)); // 6 bits
            mmsi = mmsi | ((data[6] & 0b00110000) >> 4); // 2 bits

            double size = Math.floor(Math.log10(mmsi) + 1);

            // MMSI must be 9 digits long
            if(size - 9 != 0) {
                message_integrity = State.CORRUPTED;
                return;
            }

            // 4 bits
            byte nav_state_bits = (byte)(data[6] & 0b00001111);

            if(nav_state_bits < caches_navs.length && nav_state_bits >= 0) {
                nav_state = caches_navs[nav_state_bits];
            } else {
                nav_state = AISNavigationState.UNKNOWN;
            }

            // 8 bits, 2's complement
            rate_of_turn = (byte)(rate_of_turn | (data[7] & 0b00111111) << 2); // 6 bits
            rate_of_turn = (byte)(rate_of_turn | ((data[8] & 0b00110000) >> 4)); // 2 bits

            // 10 bits
            int speed_over_ground_int = 0;
            speed_over_ground_int = speed_over_ground_int | ((data[8] & 0b00001111) << 2) << 4; // 4 bits
            speed_over_ground_int = speed_over_ground_int | (data[9] & 0b00111111); // 6 bits

            speed_over_ground = (double)speed_over_ground_int;

            // 1 bit
            position_accuracy = ((data[10] & 0b00100000) >> 5) == 1; // TODO: Represent better using enum

            // 28 bits, 2's complement
            int longitude_int = 0;
            longitude_int = longitude_int | ((data[10] & 0b00011111) << 2) << 6; // 5 bits
            longitude_int = (longitude_int | (data[11] << 2)) << 6; // 6 bits
            longitude_int = (longitude_int | (data[12] << 2)) << 6; // 6 bits
            longitude_int = (longitude_int | (data[13] << 2)) << 3; // 6 bits
            longitude_int = longitude_int | ((data[14] & 0b00111110) >> 1); // 5 bits

            // We set 4 bits before the 28-bit signed bit (MSB)
            // This corrects the number to 32-bit 2's complement
            // Note this may show as an editor error because it
            // sets the sign bit
            if((longitude_int >> 27) == 0b1) {
                //noinspection NumericOverflow
                longitude_int = (longitude_int | (0b1111 << 28));
            }

            longitude = (double)longitude_int;

            // 27 bits, 2's complement
            int latitude_int = 0;
            latitude_int = latitude_int | ((data[14] & 0b00000001) << 2) << 6; // 1 bit
            latitude_int = (latitude_int | (data[15] << 2)) << 6; // 6 bits
            latitude_int = (latitude_int | (data[16] << 2)) << 6; // 6 bits
            latitude_int = (latitude_int | (data[17] << 2)) << 6; // 6 bits
            latitude_int = (latitude_int | (data[18] << 2)); // 6 bits
            latitude_int = latitude_int | ((data[19] & 0b00110000) >> 4); // 2 bits

            if((latitude_int >> 26) == 0b1) {
                //noinspection NumericOverflow
                latitude_int = (latitude_int | (0b11111 << 27));
            }

            latitude = (double)latitude_int;

            // 12 bits
            int course_over_ground_int = 0;
            course_over_ground_int = course_over_ground_int | ((data[19] & 0b00001111) << 2) << 6; // 4 bits
            course_over_ground_int = (course_over_ground_int | (data[20] << 2)); // 6 bits
            course_over_ground_int = course_over_ground_int | ((data[21] & 0b00110000) >> 4); // 2 bits

            course_over_ground = (double)course_over_ground_int;

            // 9 bits
            true_heading = (short)(true_heading | ((data[21] & 0b00001111) << 2) << 3); // 4 bits
            true_heading = (short)(true_heading | ((data[22] & 0b00111110) >> 1)); // 5 bits

            // 6 bits
            utc_seconds = (byte)(utc_seconds | ((data[22] & 0b00000001) << 2) << 3); // 1 bit
            utc_seconds = (byte)(utc_seconds | ((data[23] & 0b00111110) >> 1)); // 5 bits

            // 2 bits
            maneuver_indicator = (byte)(maneuver_indicator | (data[23] & 0b00000001) << 1); // 1 bit
            maneuver_indicator = (byte)(maneuver_indicator | ((data[24] & 0b00100000) >> 5)); // 1 bit

            // 3 bits
            spare = (byte)(spare | ((data[24] & 0b00011100) >> 2)); // 3 bits

            // 1 bit
            //raim_flag = ((data[24] & 0b00000010) >> 1) == 1;

            // 19 bits
            radio_state = radio_state | ((data[24] & 0b00000001) << 2) << 6; // 1 bit
            radio_state = (radio_state | (data[25] << 2)) << 6; // 6 bits
            radio_state = (radio_state | (data[26] << 2)) << 4; // 6 bits
            radio_state = (radio_state | (data[27] << 2)); // 6 bits
        } else if(type == VOYAGE_DATA) {
            //TODO: Refactor this class and parse this type of message

            //repeat_indicator = (byte)(data[1] & 0b00110000);

            mmsi = mmsi | ((data[1] & 0b00001111) << 2) << 6;
            mmsi = (mmsi | (data[2] << 2)) << 6;
            mmsi = (mmsi | (data[3] << 2)) << 6;
            mmsi = (mmsi | (data[4] << 2)) << 6;
            mmsi = (mmsi | (data[5] << 2));
            mmsi = mmsi | ((data[6] & 0b00110000) >> 4);

            //byte ais_version = 0;
            //ais_version = (byte)((data[6] & 0b00001100) >> 2);

            int imo_number = 0;
            imo_number = imo_number | ((data[6] & 0b00000011) << 2) << 6; // 2 bits
            imo_number = (imo_number | (data[7] << 2)) << 6; // 6 bits
            imo_number = (imo_number | (data[8] << 2)) << 6; // 6 bits
            imo_number = (imo_number | (data[9] << 2)) << 6; // 6 bits
            imo_number = (imo_number | (data[10] << 2)) << 2; // 6 bits
            imo_number = imo_number | ((data[11] & 0b00111100) >> 2); // 4 bits

            /*
            byte call_sign[] = new byte[7];
            char call_sign2[] = new char[7];

            call_sign[0] = (byte)(((data[11] & 0b00000011) << 2) << 2);
            call_sign[0] = (byte)(call_sign[0] | ((data[12] & 0b00111100) >> 2));
            call_sign2[0] = (char)(call_sign[0] + 0x20);
            call_sign[1] = (byte)((data[12] & 0b00000011) << 4);
            call_sign[1] = (byte)(call_sign[1] | ((data[13] & 0b00111100) >> 2));
            call_sign2[1] = (char)(call_sign[1] + 0x20);
            call_sign[2] = (byte)((data[13] & 0b00000011) << 4);
            call_sign[2] = (byte)(call_sign[1] | ((data[14] & 0b00111100) >> 2));
            call_sign2[2] = (char)(call_sign[2] + 0x20);
            call_sign[3] = (byte)((data[14] & 0b00000011) << 4);
            call_sign[3] = (byte)(call_sign[1] | ((data[15] & 0b00111100) >> 2));
            call_sign2[3] = (char)(call_sign[3] + 0x20);
            call_sign[4] = (byte)((data[15] & 0b00000011) << 4);
            call_sign[4] = (byte)(call_sign[1] | ((data[16] & 0b00111100) >> 2));
            call_sign2[4] = (char)(call_sign[4] + 0x20);
            call_sign[5] = (byte)((data[16] & 0b00000011) << 4);
            call_sign[5] = (byte)(call_sign[1] | ((data[17] & 0b00111100) >> 2));
            call_sign2[5] = (char)(call_sign[5] + 0x20);
            call_sign[6] = (byte)((data[17] & 0b00000011) << 4);
            call_sign[6] = (byte)(call_sign[1] | ((data[18] & 0b00111100) >> 2));
            call_sign2[6] = (char)(call_sign[6] + 0x20);

            System.out.println(new String(call_sign2) + "\n");
            */
        } else {
            // We do not currently support the message
            message_integrity = State.NOT_SUPPORTED;
        }
    }

    /**
     * @return The index of the message in a multi-message transmission.
     */
    int getFragCount() {
        return frag_count;
    }

    /**
     * @return The number of messages for a multi-message transmission.
     */
    int getFragIndex() {
        return frag_index;
    }

    /**
     * @param previous The previous message in a multi-message transmission.
     */
    boolean setPrecedingMessage(NmeaMessage previous) {
        boolean valid = message_dependency == Dependency.PRECEDING || message_dependency == Dependency.BOTH;

        if(valid) {
            preceding_message = previous;
        }

        return valid;
    }

    /**
     * @param next The succeeding message in a multi-message transmission.
     */
    boolean setSucceedingMessage(NmeaMessage next) {
        boolean valid = message_dependency == Dependency.SUCCEEDING || message_dependency == Dependency.BOTH;

        if(valid) {
            succeeding_message = next;
        }

        return valid;
    }

    /**
     * @return An enum of type {@link Dependency} which states if this message
     * is a part of a multi-message transmission.
     */
    Dependency getMessageDependency() {
        return message_dependency;
    }

    /**
     * @return The status of the message. This must be called before
     * using any setter or getter methods to ensure that the
     * message was successfully instantiated.
     */
    State getIntegrity() {
        return message_integrity;
    }

    /**
     *
     * @return The preceding message in a multi-message transmission.
     */
    NmeaMessage getPrecedingMessage() {
        return preceding_message;
    }

    /**
     *
     * @return The succeeding message in a multi-message transmission.
     */
    NmeaMessage getSucceedingMessage() {
        return succeeding_message;
    }

    /**
     *
     * @return The AIS message type.
     */
    AISMessageType getMessageType() { return type; }

    /**
     *
     * @return True if the message is a part of the common navigation
     * block otherwise false.
     */
    boolean isCommonNavigationBlockMessage() {
        return is_cnb;
    }

    /**
     *
     * @return A nine digit ship-unique identification integer.
     */
    int getMmsi() { return mmsi; }

    /**
     *
     * @return The navigation state as determined from the message payload
     */
    AISNavigationState getNatState() { return nav_state; }

    /**
     *
     * @return The position accuracy read from the message payload
     */
    boolean getPositionAccuracy() { return position_accuracy; }

    /**
     *
     * @return The longitude read from the message payload
     */
    double getLongitude() { return longitude; }

    /**
     *
     * @return The latitude read from the message payload
     */
    double getLatitude() { return latitude; }

    /**
     *
     * @return The rate-of-turn read from the message payload
     */
    byte getRateOfTurn() { return rate_of_turn; }

    /**
     *
     * @return The speed-over-ground read from the message payload
     */
    double getSpeedOverGround() { return speed_over_ground; }

    /**
     *
     * @return The course-over-ground read from the message payload
     */
    double getCourseOverGround() { return course_over_ground; }

    /**
     *
     * @return The true heading read from the message payload
     */
    short getTrueHeading() { return true_heading; }

    /**
     *
     * @return The UTC seconds read from the message payload
     */
    byte getUtcSeconds() { return utc_seconds; }

    /**
     * @return True if the checksum of the message matched the computed checksum
     */
    boolean isChecksumValid() {
        return checksum_valid;
    }
}
