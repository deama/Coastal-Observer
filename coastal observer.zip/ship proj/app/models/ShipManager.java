package models;

import play.Logger;

import java.time.Instant;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static models.AISMessageType.VOYAGE_DATA;

/**
 * Created by mr450 on 07/10/2016.
 *
 */
class ShipManager {
    private HashMap<Integer, Ship> ships;
    private ShipTracker ship_tracker;

    ShipManager(ShipTracker ship_tracker) {
        ships = new HashMap<>();
        this.ship_tracker = ship_tracker;
    }

    void reset() {
        int size = ships.size();
        ships.clear();
        Logger.debug("ShipManager::Reset: " + size + " ships removed. Sending cleanup message to clients.");
        ship_tracker.sendCleanup();
    }

    void update(NmeaMessage message) {
        if(message.isCommonNavigationBlockMessage()) {
            int mmsi = message.getMmsi();
            AISNavigationState nav_state = message.getNatState();
            double longitude = message.getLongitude();
            double latitude = message.getLatitude();
            boolean position_accuracy = message.getPositionAccuracy();
            byte rate_of_turn = message.getRateOfTurn();
            double speed_over_ground = message.getSpeedOverGround();
            double course_over_ground = message.getCourseOverGround();
            short true_heading = message.getTrueHeading();
            byte utc_seconds = message.getUtcSeconds();
            boolean checksum_valid = message.isChecksumValid();

            Position position = Position.create(longitude, latitude, position_accuracy);
            Movement movement = Movement.create(rate_of_turn, speed_over_ground, course_over_ground, true_heading);
            ShipStateNav ship_state = new ShipStateNav(nav_state, utc_seconds, movement, position, checksum_valid);

            Ship ship;

            if(shipExists(mmsi)) {
                ship = getShip(mmsi);
                ship.addState(ship_state);
            } else {
                ship = new Ship(mmsi, ship_state);
                addShip(ship);
            }

            ship_tracker.sendShipState(mmsi, ship_state);
        } else if(message.getMessageType() == VOYAGE_DATA) {
            //TODO: Implement messages of this type
        }
    }

    void futureUpdate(NmeaMessage message) {
        if(message.isCommonNavigationBlockMessage()) {
            int mmsi = message.getMmsi();
            AISNavigationState nav_state = message.getNatState();
            double longitude = message.getLongitude();
            double latitude = message.getLatitude();
            boolean position_accuracy = message.getPositionAccuracy();
            byte rate_of_turn = message.getRateOfTurn();
            double speed_over_ground = message.getSpeedOverGround();
            double course_over_ground = message.getCourseOverGround();
            short true_heading = message.getTrueHeading();
            byte utc_seconds = message.getUtcSeconds();
            boolean checksum_valid = message.isChecksumValid();

            Position position = Position.create(longitude, latitude, position_accuracy);
            Movement movement = Movement.create(rate_of_turn, speed_over_ground, course_over_ground, true_heading);
            ShipStateNav ship_state = new ShipStateNav(nav_state, utc_seconds, movement, position, checksum_valid);

            Ship ship;

            if(shipExists(mmsi)) {
                ship = getShip(mmsi);
                ship.addPredictionState(ship_state);
            } else {
                ship = new Ship(mmsi);
                addShip(ship);
            }

        } else if(message.getMessageType() == VOYAGE_DATA) {
            //TODO: Implement messages of this type
        }
    }

    Map<Integer, ShipState> getShipStates() {
        //long maximum_age = 60 * 20;
        Map<Integer, ShipState> ship_data = new HashMap<>();

        for(Map.Entry<Integer, Ship> entry : ships.entrySet()) {
            Ship ship = entry.getValue();
            //long difference = Instant.now().getEpochSecond() - ship.getLastUpdateTimestamp();

            //if(difference < maximum_age) {
            if(ship.hasStates()) {
                ship_data.put(ship.getIdentifier(), ship.getLastShipState());
            }
            //} else {
            //    ship_data.put(ship.getIdentifier(), remove_ship_state);
            //}
        }

        return ship_data;
    }

    Map<Integer, ShipStateTrail> getTrailShipStates() {
        Map<Integer, ShipStateTrail> ship_data = new HashMap<>();

        for(Map.Entry<Integer, Ship> entry : ships.entrySet()) {
            Ship ship = entry.getValue();

            if(ship.hasStates()) {
                ship_data.put(ship.getIdentifier(), ship.getTrailShipState());
            }
        }

        return ship_data;
    }

    public void scheduleOutOfRangeShipRemoval() {
        long maximum_age = 60 * 25;

        Iterator<Map.Entry<Integer, Ship>> iterator = ships.entrySet().iterator();

        while(iterator.hasNext()) {
            Map.Entry<Integer, Ship> entry = iterator.next();
            Ship ship = entry.getValue();

            long difference = Instant.now().getEpochSecond() - ship.getLastUpdateTimestamp();

            if(difference > maximum_age) {
                iterator.remove();
                Logger.debug("Ship with ID " + ship.getIdentifier() + " has been removed.");
            }
        }
    }

    int getShipCount() {
        return ships.size();
    }

    private boolean shipExists(int mmsi) {
        return ships.containsKey(mmsi);
    }

    private Ship getShip(int mmsi) {
        return ships.get(mmsi);
    }

    private void addShip(Ship ship) {
        ships.put(ship.getIdentifier(), ship);
    }

    public void removeShip(Ship ship) {
        ships.remove(ship.getIdentifier());
    }
}
