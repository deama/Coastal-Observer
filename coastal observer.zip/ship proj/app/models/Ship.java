package models;

import utils.CircularListDecorator;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;

import static models.AISNavigationState.*;

/**
 * Created by mr450 on 06/10/2016.
 *
 * A ship with state information.
 */
public class Ship {
    // Running in offline mode
    private final static boolean OFFLINE_MODE = true;
    private final static int STATES_NEEDED_PREDICT = 10;
    private final static int WAIT_PREDICT_REUSE = 60 * 5;

    private final static int number_of_states = 200;
    private final int mmsi;
    private CircularListDecorator<ShipStateNav> ship_states;
    private ShipStateTrail ship_trail_state;
    private long last_update_timestamp;
    private int state_update_count;
    private int checksum_failure_count;
    private boolean update_ship_trail_state;

    // For the prediction system we have a collection of all states
    private HashMap<Integer, ShipStateNav> prediction_states;

    /**
     * Instantiate a new ship object with a unique identification code.
     * The ship will have no initial state
     *
     * @param mmsi The maritime mobile service identity number specific to a ship.
     */
    public Ship(int mmsi) {
        this.mmsi = mmsi;
        ship_states = new CircularListDecorator<>(new ArrayList<ShipStateNav>(), number_of_states);
        prediction_states = new HashMap<>(40);
        last_update_timestamp = 0;
        state_update_count = 1;
        checksum_failure_count = 0;
    }

    /**
     * Instantiate a new ship object with a unique identification code.
     *
     * @param mmsi The maritime mobile service identity number specific to a ship.
     * @param ship_state A "state" consisting of ship-related data at given point of time for the ship.
     */
    public Ship(int mmsi, ShipStateNav ship_state) {
        this.mmsi = mmsi;
        ship_states = new CircularListDecorator<>(new ArrayList<ShipStateNav>(), number_of_states);
        prediction_states = new HashMap<>(40);
        last_update_timestamp = 0;
        state_update_count = 1;
        checksum_failure_count = 0;
        addState(ship_state);
    }

    synchronized boolean hasStates() {
        return ship_states.size() > 0;
    }

    private synchronized void calculatePrediction(ShipStateNav ship_state) {
        // Prediction related
        int size = ship_states.size();
        double[] sog = new double[size];
        double[] heading = new double[size];
        int index = 0;

        ShipStateNav prev_state = ship_states.get((ship_states.size() - 2) % ship_states.getMaxElements());
        double longitude_prev = prev_state.getLongitude();
        double latitude_prev  = prev_state.getLatitude();

        for (ShipStateNav state : ship_states) {
            sog[index] = state.getSpeedOverGround().doubleValue();
            heading[index] = (state.getTrueHeading().doubleValue() % 360);
            index++;
        }

        ArrayList<Position> map_coordinates = ShipPredictionMap.predict(longitude_prev, latitude_prev, ship_state.getLongitude(), ship_state.getLatitude());
        ShipStateNav.PredictType type;
        double[] predictions = prev_state.getPredictions();
        boolean predict_reuse = false;
        long time = Instant.now().getEpochSecond();

        // If no coordinates generated then we rely on the Predict system
        if(map_coordinates.size() == 0) {
            long difference = Math.abs(prev_state.getPredictionTime() - time);
            predict_reuse = prev_state.getPredictType() == ShipStateNav.PredictType.MAP && difference < WAIT_PREDICT_REUSE;

            if(predict_reuse) {
                type = ShipStateNav.PredictType.MAP; // We can reuse the previous prediction
            } else {
                map_coordinates = Predict.predictLocation(ship_state.getLatitude(), ship_state.getLongitude(), sog, heading, 0);
                type = ShipStateNav.PredictType.PREDICT; // We will use the Predict system
            }
        } else {
            type = ShipStateNav.PredictType.MAP; // The returned result has new prediction coordinates
        }

        if(predict_reuse) {
            time = prev_state.getPredictionTime();

            // A quick way to remove coordinates that our ship is moving away from
            double previous_latitude = predictions[0];
            double previous_longitude = predictions[1];
            double new_latitude = ship_state.getLatitude();
            double new_longitude = ship_state.getLongitude();

            for(int i = 2; i < (predictions.length - 4); i += 2) {
                double distance_lat_prev = Math.abs(predictions[i] - previous_latitude);
                double distance_long_prev = Math.abs(predictions[i + 1] - previous_longitude);

                double distance_lat_new = Math.abs(predictions[i] - new_latitude);
                double distance_long_new = Math.abs(predictions[i + 1] - new_longitude);

                if(distance_long_new + distance_lat_new > distance_long_prev + distance_lat_prev) {
                    predictions[i] = new_latitude;
                    predictions[i + 1] = new_longitude;
                }
            }

            predictions[0] = ship_state.getLatitude();
            predictions[1] = ship_state.getLongitude();
        } else {
            predictions = new double[(map_coordinates.size() * 2) + 2];
            predictions[0] = ship_state.getLatitude();
            predictions[1] = ship_state.getLongitude();
            index = 2;

            for (Position pos : map_coordinates) {
                predictions[index++] = pos.getLatitude();
                predictions[index++] = pos.getLongitude();
            }
        }

        ship_state.setPredictionAttributes(predictions, type, time);
    }

    synchronized void addState(ShipStateNav ship_state) {
        ship_states.add(ship_state);
        last_update_timestamp = Instant.now().getEpochSecond();
        state_update_count++;
        update_ship_trail_state = true;

        if(!ship_state.isChecksumValid()) {
            checksum_failure_count += 1;
        }

        AISNavigationState status = ship_state.getNavState();

        boolean no_speed = ship_state.getSpeedOverGround().equals(0d);
        // Some ships do not use the AIS status system correctly
        boolean ship_moving = (status == UNDER_WAY_USING_ENGINE || status == UNDER_WAY_SAILING ||
                (status != MOORED && status != AGROUND && status != USING_ANCHOR)) && !no_speed;

        if(ship_states.size() >= STATES_NEEDED_PREDICT && ship_moving) {
            calculatePrediction(ship_state);
        }
    }

    synchronized void addPredictionState(ShipStateNav ship_state) {
        prediction_states.put(ship_state.getUtcSeconds(), ship_state);
    }

    synchronized ShipStateNav lookupPredictionState(int utc_seconds) {
        return null;
    }

    synchronized int getIdentifier() {
        return mmsi;
    }

    synchronized ShipStateNav getLastShipState() {
        return ship_states.getLastElement();
    }

    synchronized ShipStateTrail getTrailShipState() {
        // If the trail state is not up-to-date
        // then we construct a new trail state
        if(update_ship_trail_state) {
            int size = (ship_states.size() * 2);
            Double positions[] = new Double[size];
            int index = size - 1;

            // First is most recent ship state
            // Last is oldest ship state
            // Latitude first, then longitude
            for(ShipStateNav state : ship_states) {
                positions[index--] = state.getLongitude();
                positions[index--] = state.getLatitude();
            }

            ShipState ship_state = ship_states.get(ship_states.size() - 1);
            ship_trail_state = new ShipStateTrail(ship_state, positions);
            update_ship_trail_state = false;
        }

        return ship_trail_state;
    }

    synchronized long getLastUpdateTimestamp() {
        return last_update_timestamp;
    }
}
