package models;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import play.Logger;

import java.io.File;
import java.nio.charset.Charset;
import java.time.Instant;
import java.util.List;

/**
 * Created by mr450 on 31/10/16.
 *
 */
public class CsvNmeaProducer implements NmeaProducerInterface {
    public enum Exit {
        ON_EXCEPTION,
        ON_READ_ALL
    }

    // 50 == 399 minutes to process all messages
    private static final int time_modifier = 24;
    // Max time to wait between each message
    private static final int max_wait = 10000;

    private long start_timestamp;
    private final MessageProcessorInterface callback;
    private final Exit exit_on;
    private final List<CSVRecord> records;
    private int index;

    /**
     * Instantiate a new {@link NmeaProducerInterface} that will create
     * {@link NmeaMessage} objects.
     *
     * @param file_path The path to the CSV file.
     * @param callback New messages will be sent to this object.
     * @param exit_on Specify how this {@link NmeaProducerInterface} should exit once it has finished reading.
     * @throws java.io.IOException The {@link CSVParser} may encounter an error with opening the CSV file.
     */
    CsvNmeaProducer(String file_path, MessageProcessorInterface callback, Exit exit_on) throws java.io.IOException {
        this.callback = callback;
        this.exit_on = exit_on;
        File csv_file = new File(file_path);
        CSVParser parser = CSVParser.parse(csv_file, Charset.defaultCharset(), CSVFormat.DEFAULT);
        records = parser.getRecords();
        index = 0;
    }

    /**
     * Instantiate a new {@link NmeaProducerInterface} that will create
     * {@link NmeaMessage} objects. This does not create a {@link CSVParser} object.
     *
     * @param records The {@link CSVRecord} objects that will be read into messages.
     * @param callback New messages will be sent to this object.
     * @param exit_on Specify how this {@link NmeaProducerInterface} should exit once it has finished reading.
     */
    public CsvNmeaProducer(List<CSVRecord> records, MessageProcessorInterface callback,  Exit exit_on) {
        this.records = records;
        this.callback = callback;
        this.exit_on = exit_on;
        index = 0;
        start_timestamp = 0;
    }

    /**
     * Parse a {@link CSVRecord} into an {@link NmeaMessage} object.
     * This does not link multi-part messages.
     *
     * @param index The index of the {@link CSVRecord}.
     * @return The new message object.
     */
    private NmeaMessage getMessage(int index) {
        CSVRecord record = records.get(index);
        NmeaMessage message = NmeaMessage.defaultNmeaMessage();

        if (record.get(0).equals("!AIVDM")) {
            // Fragment count indexing starts at 1 so that
            // last fragment index == fragment count
            int frag_count;
            int frag_index;
            boolean checksum_valid = false;

            try {
                frag_count = Integer.parseInt(record.get(1));
                frag_index = Integer.parseInt(record.get(2));
            } catch (NumberFormatException ex) {
                // We are unable to read fragment values
                // so we assign them an error value which
                // will force a integrity failure for the
                // message
                frag_count = 0;
                frag_index = 0;
            }

            int checksum_actual;
            // We exclude the checksum value
            int number_of_values = record.size() - 1;
            char ending_char;
            // Set to initial 'AIVDM' XOR value. This
            // never changes between messages
            int checksum = 87;

            try {
                // The checksum is always at the end of an NMEA sentence
                // It is always two digits
                String checksum_letters = record.get(number_of_values);
                // We need the first letter (separator) from the checksum
                ending_char = checksum_letters.charAt(0);
                // The checksum is always in hexadecimal form
                checksum_actual = Integer.parseInt(checksum_letters.substring(2), 16);

                for (int value_index = 1; value_index < number_of_values; value_index++) {
                    byte[] bytes = record.get(value_index).getBytes();

                    for (byte char_code : bytes) {
                        checksum ^= char_code;
                    }
                }

                checksum ^= ending_char;
                checksum_valid = (checksum == checksum_actual);
            } catch (NumberFormatException | StringIndexOutOfBoundsException ignored) {
                // Checksum validity is already initialised to false
            }

            String payload = record.get(5);
            message = NmeaMessage.create(payload, frag_count, frag_index, checksum_valid);
        }

        return message;
    }

    /**
     * Parse a {@link CSVRecord} into an {@link NmeaMessage} object.
     * This links multi-part messages.
     *
     * @param read_initial The starting index in the {@link List<CSVRecord>}
     * @param read_until The number of {@link CSVRecord} objects to read
     * @param message_list Store new {@link NmeaMessage} objects here.
     * @return True if new {@link NmeaMessage} objects have been stored, false otherwise.
     */
    public boolean fill(int read_initial, int read_until, List<NmeaMessage> message_list) {
        int list_size_before = message_list.size();
        NmeaMessage added_message = null;
        FillState status = FillState.FIRST_MESSAGE_NOT_SET;
        int added_message_index = 0;

        for(int index = read_initial; index < read_until; index++) {
            NmeaMessage message = getMessage(index);
            int frag_index = message.getFragIndex();

            if(message.getIntegrity() == NmeaMessage.State.OK) {
                if(frag_index == 1) {
                    // When a new message has a fragment size greater than 1 then
                    // we need to know where the first message is stored in the
                    // message list. By keeping a record of every first message
                    // temporarily, we can check and remove the entire corrupted
                    // message chain
                    added_message_index = message_list.size();
                    message_list.add(message);
                    status = FillState.FIRST_MESSAGE_SET;
                } else {
                    if(added_message != null) {
                        message.setPrecedingMessage(added_message);
                        added_message.setSucceedingMessage(message);
                    }
                }

                added_message = message;
            } else {
                if(frag_index > 1 && status == FillState.FIRST_MESSAGE_SET) {
                    message_list.remove(added_message_index);
                }

                status = FillState.FIRST_MESSAGE_NOT_SET;
            }
        }

        return list_size_before != message_list.size();
    }

    /**
     * Creates a new valid {@link NmeaMessage} object if possible otherwise returns
     * a default {@link NmeaMessage} object with a failure state.
     *
     * @return The new {@link NmeaMessage}, otherwise {@link NmeaMessage}
     * object with an error state
     */
    private NmeaMessage readNextMessage() {
        if(index == 0) {
            start_timestamp = Instant.now().getEpochSecond();
        }

        NmeaMessage message = getMessage(index);
        index = (index + 1) % records.size();

        return message;
    }

    /**
     * Creates new AIS NMEA messages using realistic delays.
     * Simulate message flow delays via AIS UTC seconds values.
     * Delays are scaled using a modifier. Large delays over
     * a certain threshold are skipped. New messages are
     * sent to the object that implements {@link MessageProcessorInterface}.
     */
    public void getMessageData() {
        int start = index;
        NmeaMessage message = readNextMessage();
        NmeaMessage previous_message;
        int first_utc = message.getUtcSeconds();
        int second_utc;
        int count = 0;

        // Check if this loop should break once
        // all records have been read or if it
        // should continue indefinitely using
        // wrap-around
        while((exit_on == Exit.ON_READ_ALL && count < records.size()) || exit_on == Exit.ON_EXCEPTION) {
            if(count >= records.size()) { // Condition will only be met when on exception exit only
                count = 0;
            }

            previous_message = message;

            if(message.getIntegrity() == NmeaMessage.State.OK) {
                callback.update(message);
                message = readNextMessage();
                second_utc = first_utc;
                first_utc = message.getUtcSeconds();

                long difference = Math.abs((first_utc - second_utc) * time_modifier);

                if(difference < max_wait) {
                    try {
                        Thread.sleep(difference);
                    } catch (InterruptedException ex) {
                        Logger.error("CsvNmeaProducer::getMessageData", ex);
                    }
                } else {
                    Logger.debug("CsvNmeaProducer::getMessageData: Time exceeded; difference is " + difference + ".");
                }
            } else {
                message = readNextMessage();
            }

            // Once we have read all the message
            // we reset the system
            if(index == start) {
                long wait_time = (Instant.now().getEpochSecond() - start_timestamp) / 60;
                Logger.debug("CsvNmeaProducer::getMessageData: It took " + wait_time + " minutes to read all the messages.");
                callback.reset();
            }

            NmeaMessage.Dependency depends = message.getMessageDependency();

            switch(depends) {
                case PRECEDING:
                case BOTH:
                    message.setPrecedingMessage(previous_message);
                    previous_message.setSucceedingMessage(message);
                    break;
                case NONE:
                default:
                    break;
            }

            count++;
        }
    }

    /**
     * @return The number of records that have been read from a CSV file.
     */
    public int getRecordCount() {
        return records.size();
    }
}
