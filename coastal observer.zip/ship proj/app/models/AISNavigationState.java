package models;

/**
 * Created by mr450 on 21/01/2017.
 *
 * Represents Navigation Status values.
 *
 * Based on the specifications found under row four on
 * the table found at:
 * http://www.navcen.uscg.gov/?pageName=AISMessagesA
 */
enum AISNavigationState {
    UNDER_WAY_USING_ENGINE("Under way using engine"),
    USING_ANCHOR("Using anchor"),
    NOT_UNDER_COMMAND("Not under command"),
    RESTRICTED_MANEUVERABILITY("Restricted Maneuverability"),
    CONSTRAINED_BY_HER_DRAUGHT("Constrained by her draught"),
    MOORED("Moored"),
    AGROUND("Aground"),
    ENGAGED_IN_FISHING("Engaged in fishing"),
    UNDER_WAY_SAILING("Under way using sails"),
    RESERVED_HSC("Reserved for HSC"),
    RESERVED_WIG("Reserved for WIG"),
    RESERVED_A("Reserved"),
    RESERVED_B("Reserved"),
    RESERVED_C("Reserved"),
    AIS_SART_IS_ACTIVE("AIS-SART is active"),
    DEFAULT("No status"),
    UNKNOWN("Unknown"); // Not a part of the standard

    private final String description;

    AISNavigationState(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return description;
    }
}
