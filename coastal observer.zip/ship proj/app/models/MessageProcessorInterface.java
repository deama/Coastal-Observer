package models;

/**
 * Created by mr450 on 28/11/2016.
 *
 */
public interface MessageProcessorInterface {
    void reset();
    void update(NmeaMessage message);
    void updatePrediction(NmeaMessage message);
}
