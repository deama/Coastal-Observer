package models;

import utils.ListenableThreadFactory;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Created by mr450 on 28/11/2016.
 *
 */
class ShipManagerScheduler implements MessageProcessorInterface {
    private ShipManager ship_manager;
    private ExecutorService executor;

    ShipManagerScheduler(ShipManager ship_manager) {
        executor = Executors.newSingleThreadExecutor(new ListenableThreadFactory());
        this.ship_manager = ship_manager;
    }

    @Override
    public void reset() {
        executor.execute(() -> ship_manager.reset());
    }

    @Override
    public void update(NmeaMessage message) {
        executor.execute(() -> ship_manager.update(message));
    }

    @Override
    public void updatePrediction(NmeaMessage message) {
        executor.execute(() -> ship_manager.futureUpdate(message));
    }

    Future<Map<Integer, ShipState>> getShipStates() {
        return executor.submit(() -> ship_manager.getShipStates());
    }

    Future<Map<Integer, ShipStateTrail>> getTrailShipStates() {
        return executor.submit(() -> ship_manager.getTrailShipStates());
    }

    Future<Integer> getShipCount() {
        return executor.submit(() -> ship_manager.getShipCount());
    }
}
