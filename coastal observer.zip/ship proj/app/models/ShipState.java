package models;

import java.util.Map;

/**
 * Created by mr450 on 19/02/2017.
 *
 */
interface ShipState {
    Double[] getPositions();
    Number[] getMovements();
    Map<String, Object> getCharacteristics();
    double[] getPredictions();
}
