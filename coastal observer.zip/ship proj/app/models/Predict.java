package models;

import java.util.ArrayList;

/**
 * Created by Christopher Millar on 28/01/2017.
 *
 * Class that will control the prediction of the ships next locations.
 */
class Predict {
    private static final int MAX_DEPTH = 4;

    static ArrayList<Position> predictLocation(double latitude, double longitude, double[] speed_over_ground, double[] true_heading, int depth) {
        ArrayList<Position> prediction_attributes = new ArrayList<>();
        predictLocation(latitude, longitude, speed_over_ground, true_heading, depth, prediction_attributes);
        return prediction_attributes;
    }

    private static void predictLocation(double latitude, double longitude, double[] speed_over_ground, double[] true_heading, int depth, ArrayList<Position> prediction_attributes) {
        double speed_over_groundCurrent = speed_over_ground[speed_over_ground.length - 1]; // Last value in array = most recent
        double true_headingCurrent = true_heading[true_heading.length - 1] - 90; // Last value in array = most recent

        double trueHeadingNewValue = sum(true_heading) / true_heading.length; // Average true heading
        double speed_over_groundNewValue = sum(speed_over_ground) / speed_over_ground.length; // Average speed over ground

        double[] true_headingNew = new double[true_heading.length + 1];

        System.arraycopy(true_heading, 1, true_headingNew, 1, true_heading.length - 1);

        true_headingNew[true_headingNew.length-1] = trueHeadingNewValue;

        double[] speed_over_groundNew = new double[speed_over_ground.length + 1];

        System.arraycopy(speed_over_ground, 1, speed_over_groundNew, 1, speed_over_ground.length - 1);

        speed_over_groundNew[speed_over_groundNew.length-1] = speed_over_groundNewValue;

        //cos and sin require radians
        double true_headingRAD = Math.toRadians(true_headingCurrent);

        double time = 0.01111111111d; //this is 40 seconds

        double Vx = speed_over_groundCurrent * Math.sin(true_headingRAD);
        double Vy = speed_over_groundCurrent * Math.cos(true_headingRAD);

        double latitudeNew = latitude + time * Vy / 60;
        double longitudeNew = longitude + time * Vx / Math.cos(Math.toRadians(latitudeNew)) / 60;

        latitudeNew = (double) Math.round(latitudeNew * 100000d) / 100000d;
        longitudeNew = (double) Math.round(longitudeNew * 100000d) / 100000d;
        prediction_attributes.add(Position.wrap(longitudeNew, latitudeNew));

        if (depth < MAX_DEPTH) {
            predictLocation(latitudeNew, longitudeNew, speed_over_groundNew, true_headingNew, ++depth, prediction_attributes);
        }
    }

    private static double sum(double[] values) {
        double result = 0;
        for (double value : values) {
            result += value;
        }

        return result;
    }
}
