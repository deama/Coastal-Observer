package models;

import java.util.ArrayList;

/**
 * Created by mr450 on 07/10/2016.
 *
 * Represents all forms of rotation, speed and other "movement"
 * attributes for an entity. Values are immutable.
 */
class Movement {
    private final ArrayList<Number> cache_attributes;
    private final int rate_of_turn;
    private final double speed_over_ground;
    private final double course_over_ground;
    private final int true_heading;

    static Movement create(byte rate_of_turn, double speed_over_ground, double course_over_ground, short true_heading) {
        Movement movement;

        if(validateMovementValues(rate_of_turn, speed_over_ground, course_over_ground, true_heading)) {
            movement = new Movement(rate_of_turn, speed_over_ground, course_over_ground, true_heading);
        } else {
            movement = new UnusableMovement(rate_of_turn, speed_over_ground, course_over_ground, true_heading);
        }

        return movement;
    }

    Movement(byte rate_of_turn, double speed_over_ground, double course_over_ground, short true_heading) {
        cache_attributes = new ArrayList<>(4);
        this.rate_of_turn = rate_of_turn;
        this.speed_over_ground = speed_over_ground / 10.0d;
        this.course_over_ground = course_over_ground / 10.0d;

        // Rotate by an additional 90 for front-end correction
        this.true_heading = true_heading + 90;
    }

    private static boolean validateMovementValues(byte rate_of_turn, double speed_over_ground, double course_over_ground, short true_heading) {
        boolean strict_check = rate_of_turn == -128 || speed_over_ground == 1023;
        strict_check = strict_check || course_over_ground == 3600;

        return true_heading != 511 || strict_check;
    }

    int getRateOfTurn() {
        return rate_of_turn;
    }

    double getSpeedOverGround() {
        return speed_over_ground;
    }

    double getCourseOverGround() {
        return course_over_ground;
    }

    int getTrueHeading() {
        return true_heading;
    }
}