package models;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

/**
 * Created by mr450 on 22/01/2017.
 *
 */
public class ShipStateTrail implements ShipState {
    private final ShipState ship_state;
    private final Double[] all_positions;


    ShipStateTrail(ShipState ship_state, Double[] all_positions) {
        this.ship_state = ship_state;
        this.all_positions = all_positions;
    }

    @JsonProperty("Position")
    public synchronized Double[] getPositions() {
        return all_positions;
    }

    @JsonProperty("Movement")
    public synchronized Number[] getMovements() {
        return ship_state.getMovements();
    }

    @JsonProperty("Statistics")
    public synchronized Map<String, Object> getCharacteristics() {
        return ship_state.getCharacteristics();
    }

    @JsonProperty("Prediction")
    public synchronized double[] getPredictions(){return ship_state.getPredictions() ;}

}
