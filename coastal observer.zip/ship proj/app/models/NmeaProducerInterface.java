package models;

import java.util.List;

/**
 * Created by mr450 on 07/10/2016.
 * 
 */
interface NmeaProducerInterface {
    enum FillState {
        FIRST_MESSAGE_NOT_SET,
        FIRST_MESSAGE_SET
    }

    void getMessageData();
    boolean fill(int read_initial, int read_until, List<NmeaMessage> message_list);
    int getRecordCount();
}
