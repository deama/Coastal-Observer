package models;

import com.fasterxml.jackson.databind.JsonNode;
import controllers.UserManager;
import play.Logger;
import play.libs.Json;
import services.AisVdmSource;
import utils.ListenableThreadFactory;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static models.CsvNmeaProducer.Exit.ON_EXCEPTION;

/**
 * Created by mr450 on 18/10/2016.
 *
 */
public class ShipTracker {
    private NmeaProducerInterface nmea_producer;
    private final ExecutorService nmea_producer_executor;
    private final ShipManagerScheduler ship_manager_scheduler;
    private final UserManager user_manager;

    @Inject
    public ShipTracker(AisVdmSource source, UserManager user_manager) {
        Logger.info("Starting Ship Tracking Service\n");
        ShipManager ship_manager = new ShipManager(this);
        ship_manager_scheduler = new ShipManagerScheduler(ship_manager);
        this.user_manager = user_manager;

        // Initialise the nodes for the Ship Prediction Map system
        ShipPredictionMap.generate();

        // New data is gathered asynchronously and sent to the
        // message processor
        nmea_producer_executor = Executors.newSingleThreadExecutor(new ListenableThreadFactory());

        String path = source.getCsvFilePath("ais_data_201611130950");

        try {
            nmea_producer = new CsvNmeaProducer(path, ship_manager_scheduler, ON_EXCEPTION);
        } catch (NullPointerException | java.io.IOException ex) {
            Logger.error("ShipTracker::ShipTracker:", ex);
            return;
        }

        LinkedList<NmeaMessage> records = new LinkedList<>();
        nmea_producer.fill(0, nmea_producer.getRecordCount(), records);
        records.forEach(ship_manager_scheduler::updatePrediction);

        try {
            int count = ship_manager_scheduler.getShipCount().get();
            Logger.debug("There are " + records.size() + " messages to be processed into ships and states.");
            Logger.info("There are " + count + " ships in the ship manager.");
        } catch(InterruptedException | ExecutionException ex) {
            Logger.error("ShipTracker::ShipTracker:", ex);
            return;
        }

        runNewProducerTask();
    }

    private void runNewProducerTask() {
        nmea_producer_executor.execute(() -> {
            Logger.info("NMEA message system running.");
            nmea_producer.getMessageData();
            runNewProducerTask();
        });
    }

    void sendCleanup() {
        JsonNode serialised = Json.toJson("RESET");
        user_manager.publish(serialised);
    }

    void sendShipState(Integer identifier, ShipState state) {
        HashMap<Integer, ShipState> map = new HashMap<>();
        map.put(identifier, state);
        JsonNode serialized = Json.toJson(map);
        user_manager.publish(serialized);
    }

    public Future<Integer> getShipCount() {
        return ship_manager_scheduler.getShipCount();
    }

    public Future<Map<Integer, ShipState>> getShipStates() {
        return ship_manager_scheduler.getShipStates();
    }

    public Future<Map<Integer, ShipStateTrail>> getTrailShipStates() {
        return ship_manager_scheduler.getTrailShipStates();
    }
}
