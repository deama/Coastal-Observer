package models;

/**
 * Created by mr450 on 07/10/2016.
 *
 * Represents the position of an entity as longitude and
 * latitude. Values are immutable.
 *
 * Note that the ordering is longitude first then latitude.
 * This follows the convention of the AIS-NMEA data format where
 * longitude is encoded first in a CNB-type message.
 */
class Position {
    private double longitude;
    private double latitude;
    private boolean position_accuracy;

    /**
     * If the position values are valid then this method will return
     * a valid Position object otherwise it will return a {@link UnusablePosition}
     * object.
     *
     * @param longitude The longitude of an entity.
     * @param latitude The latitude of an entity.
     * @param position_accuracy The positional accuracy of an entity.
     * @return A new {@link Position} object or an object that class extends.
     */
    static Position create(double longitude, double latitude, boolean position_accuracy) {
        Position position;

        if(validatePositionalValues(longitude, latitude)) {
            position = new Position(longitude, latitude, position_accuracy);
        } else {
            position = new UnusablePosition(longitude, latitude, position_accuracy);
        }

        return position;
    }

    /**
     * Returns a new {@link Position} object that has not modified
     * the longitude or latitude values passed into it.
     *
     * @return A new {@link Position} object.
     */
    static Position wrap(double longitude, double latitude) {
        return new Position(longitude, latitude);
    }

    /**
     * @param longitude The longitude of an entity.
     * @param latitude The latitude of an entity.
     * @param position_accuracy The positional accuracy of an entity.
     */
    Position(double longitude, double latitude, boolean position_accuracy) {
        this.longitude = longitude / 600000.0;
        this.longitude = (double)Math.round(this.longitude * 100000d) / 100000d; // Four decimal places
        this.latitude = latitude / 600000.0d;
        this.latitude = (double)Math.round(this.latitude * 100000d) / 100000d; // Four decimal places
        this.position_accuracy = position_accuracy;
    }

    /**
     * A constructor that does not modify the longitude and latitude values.
     * Position accuracy is set to false by using this constructor.
     *
     * @param longitude The longitude of an entity.
     * @param latitude The latitude of an entity.
     */
    private Position(double longitude, double latitude) {
        this.longitude = longitude;
        this.latitude = latitude;
        this.position_accuracy = false;
    }


    /**
     * Validate the values given through the constructor
     * to ensure that they are usable.
     */
    private static boolean validatePositionalValues(double longitude, double latitude) {
        return (longitude != 181 || latitude != 91);
    }

    /**
     * @return The longitude of an entity.
     */
    double getLongitude() {
        return longitude;
    }

    /**
     * @return The latitude of an entity.
     */
    double getLatitude() {
        return latitude;
    }
}