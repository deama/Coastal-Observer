package models;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by mr450 on 03/11/2016.
 *
 */
public class ShipStateNav implements ShipState {
    enum PredictType {
        MAP,
        PREDICT
    }

    private final AISNavigationState nav_state;
    private final int utc_seconds;
    private final boolean checksum_valid;
    private final Number[] movement_attributes;
    private final Double[] position_attributes;
    private double[] prediction_attributes;
    private PredictType predict_type;
    private long prediction_time;

    ShipStateNav(AISNavigationState nav_state, int utc_seconds, Movement movement, Position position, boolean checksum_valid) {
        this.nav_state = nav_state;
        this.utc_seconds = utc_seconds;
        this.checksum_valid = checksum_valid;

        // We store the ship state data into
        // arrays to avoid repeated initialisation
        // and copying of values
        movement_attributes = new Number[4];
        movement_attributes[0] = movement.getRateOfTurn();
        movement_attributes[1] = movement.getSpeedOverGround();
        movement_attributes[2] = movement.getCourseOverGround();
        movement_attributes[3] = movement.getTrueHeading();
        position_attributes = new Double[2];
        position_attributes[0] = position.getLatitude();
        position_attributes[1] = position.getLongitude();

        prediction_time = 0;
        prediction_attributes = new double[0];
        predict_type = PredictType.PREDICT;
    }

    synchronized void setPredictionAttributes(double[] prediction_attributes, PredictType predict_type, long time) {
        this.prediction_attributes = prediction_attributes;
        this.predict_type = predict_type;
        this.prediction_time = time;
    }

    synchronized boolean isChecksumValid() {
        return checksum_valid;
    }

    synchronized Number getSpeedOverGround() {
        return movement_attributes[1];
    }

    synchronized Number getTrueHeading() {
        return movement_attributes[3];
    }

    synchronized Double getLatitude() {
        return position_attributes[0];
    }

    synchronized Double getLongitude() {
        return position_attributes[1];
    }

    synchronized AISNavigationState getNavState() { return nav_state; }

    synchronized int getUtcSeconds() { return utc_seconds; }

    synchronized PredictType getPredictType() { return predict_type; }

    synchronized long getPredictionTime() {
        return prediction_time;
    }

    @JsonProperty("Position")
    public synchronized Double[] getPositions() {
        return position_attributes;
    }

    @JsonProperty("Movement")
    public synchronized Number[] getMovements() {
        return movement_attributes;
    }

    @JsonProperty("Statistics")
    public synchronized Map<String, Object> getCharacteristics() {
        HashMap<String, Object> map = new HashMap<>();
        map.put("Checksum", checksum_valid);
        map.put("Seconds", utc_seconds);
        map.put("Size", "Not implemented");
        map.put("Status", nav_state.toString());
        return map;
    }

    @JsonProperty("Prediction")
    public synchronized double[] getPredictions() {
        return prediction_attributes;
    }
}
