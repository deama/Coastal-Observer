package models;

import java.util.ArrayList;

/**
 * Created by mr450 on 16/03/2017.
 *
 */
class ShipPredictionMap {
    private static ArrayList<MapNode> map_nodes = new ArrayList<>();
    private static final double distance = 0.001;
    private static final NoNode no_node = new NoNode("Dead end", 0, 0, 0);

    private static class MapNode {
        String name;
        Position position;
        double magnitude;
        MapNode next;
        MapNode prev;

        MapNode(String name, double longitude, double latitude, int magnitude) {
            this.name = name;
            this.position = Position.wrap(longitude, latitude);
            this.magnitude = (distance * magnitude);
            this.next = no_node;
            this.prev = no_node;

            if(magnitude != 0) {
                map_nodes.add(this);
            }
        }

        void join(MapNode node) {
            this.next = node;
            node.prev = this;
        }
    }

    private static class NoNode extends MapNode {
        NoNode(String name, double longitude, double latitude, int magnitude) {
            super(name, longitude, latitude, magnitude);
        }


    }

    static void generate() {
        // Setup NoNode
        no_node.join(no_node);

        // Dover port Area
        MapNode a1 = new MapNode("Dover Port dock North", 1.33685d, 51.12510d, 1);
        MapNode a2 = new MapNode("Dover Port entrance North (Southern Breakwater)", 1.343572d, 51.120971d, 2);
        MapNode a3 = new MapNode("Dover Port entrance North Extended", 1.35050d, 51.12048d, 3);
        MapNode a4 = new MapNode("Dover Port sea North 1", 1.374300d, 51.114882d, 5);
        MapNode a5 = new MapNode("Dover Port sea North 2", 1.45885d, 51.10750d, 5);
        a5.join(a4);
        a4.join(a3);
        a3.join(a2);
        a2.join(a1);
        MapNode b1 = new MapNode("Dover Port dock South", 1.33383d, 51.12267d, 1);
        MapNode b2 = new MapNode("Dover Port entrance South (Southern Breakwater)", 1.329024d, 51.112054d, 1);
        MapNode b3 = new MapNode("Dover Port entrance South Extended", 1.329024d, 51.112054d, 2);
        MapNode b4 = new MapNode("Dover Port sea South 1", 1.366618d, 51.117738d, 3);
        MapNode b5 = new MapNode("Dover Port sea South 2", 1.336598d, 51.098254d, 5);
        b5.join(b4);
        b4.join(b3);
        b3.join(b2);
        b2.join(b1);

        // Calais port area
        MapNode c1 = new MapNode("Calais Port dock", 1.848157, 50.967568, 2);
        MapNode c2 = new MapNode("Calais Port entrance", 1.840155, 50.971930, 2);
        MapNode c3 = new MapNode("Calais Port entrance extended", 1.81222, 50.97165, 3);
        MapNode c4 = new MapNode("Calais Port sea 1", 1.783436, 50.988562, 10);
        MapNode c5 = new MapNode("Calais Port sea 2", 1.724056, 51.001151, 10);
        MapNode c6 = new MapNode("Calais Port sea 3", 1.707782, 51.004603, 10);
        c6.join(c5);
        c5.join(c4);
        c4.join(c3);
        c2.join(c1);

        // Dunkirk port area
        MapNode d1 = new MapNode("Dunkirk Port dock", 2.183042, 51.019130, 4);
        MapNode d2 = new MapNode("Dunkirk Port entrance", 2.171922, 51.022651, 2);
        MapNode d3 = new MapNode("Dunkirk Port entrance extended", 2.170222, 51.039902, 5);
        MapNode d4 = new MapNode("Dunkirk Port sea 1", 2.170222, 51.039902, 5);
        MapNode d5 = new MapNode("Dunkirk Port sea 1", 1.947716, 51.081318, 10);
        d5.join(d4);
        d4.join(d3);
        d3.join(d2);
        d2.join(d1);

        // Calais port area alternative
        MapNode e1 = new MapNode("Calais Alternative Port sea 1", 1.832819, 50.972143, 1);
        MapNode e2 = new MapNode("Calais Alternative Port sea 2", 1.80299, 50.97112, 5);
        MapNode e3 = new MapNode("Calais Alternative Port sea 3", 1.79025, 50.96732, 5);
        e3.join(e2);
        e2.join(e1);

        // Sea Channel South
        MapNode f1 = new MapNode("South Sea 1", 1.47802, 50.92397, 30);
        MapNode f2 = new MapNode("South Sea 2", 1.57557, 50.99777, 10);
        MapNode f3 = new MapNode("South Sea 3", 1.76167, 51.08711, 10);
        f1.next = f2;
        f2.next = f3;

        // Sea Channel North
        MapNode g1 = new MapNode("North Sea 1", 1.68904, 51.17746, 30);
        MapNode g2 = new MapNode("North Sea 2", 1.56583, 51.13500, 10);
        MapNode g3 = new MapNode("North Sea 3", 1.38805, 51.03849, 10);
        MapNode g4 = new MapNode("North Sea 4", 1.11859, 50.87293, 10);
        g1.next = g2;
        g2.next = g3;
        g3.next = g4;

        // North Dover Detail
        MapNode h1 = new MapNode("North Dover 1", 1.39285, 51.11617, 10);
        h1.next = a3;
    }

    static ArrayList<Position> predict(double longitude_prev, double latitude_prev, double longitude, double latitude) {
        ArrayList<Position> positions = new ArrayList<>();

        // Naive search for nearest node to current latitude and longitude
        MapNode node = no_node;
        double distance_lat = 1000;
        double distance_long = 1000;
        for(MapNode possible : map_nodes) {
            double distance_lat_new = Math.abs(possible.position.getLatitude() - latitude);
            double distance_long_new = Math.abs(possible.position.getLongitude() - longitude);
            boolean valid_range = (distance_lat_new < possible.magnitude) && (distance_long_new < possible.magnitude);

            if(valid_range && (distance_lat_new + distance_long_new) < (distance_lat + distance_long)) {
                node = possible;
            }
        }

        if(node != no_node) {
            // Check if we should go up or down the structure
            // by checking the distances of the child nodes
            double next_distance = Math.abs(node.next.position.getLatitude() - latitude_prev);
            next_distance += Math.abs(node.next.position.getLongitude() - longitude_prev);
            next_distance += Math.abs(node.next.position.getLatitude() - latitude);
            next_distance += Math.abs(node.next.position.getLongitude() - longitude);

            double prev_distance = Math.abs(node.prev.position.getLatitude() - latitude_prev);
            prev_distance += Math.abs(node.prev.position.getLongitude() - longitude_prev);
            next_distance += Math.abs(node.prev.position.getLatitude() - latitude);
            next_distance += Math.abs(node.prev.position.getLongitude() - longitude);

            boolean direct_comp = (next_distance > prev_distance);

            MapNode next_node = node;
            boolean finished = false;

            // Loop through the nodes. Nodes are linked with bi-directional association
            // therefore we check that the next node descendant is not the same node
            while(next_node != no_node && !finished) {
                positions.add(next_node.position);
                MapNode loop_check_node;

                if(direct_comp) {
                    next_node = next_node.next;
                    loop_check_node = next_node.next.next;
                } else {
                    next_node = next_node.prev;
                    loop_check_node = next_node.prev.prev;
                }

                // Check for looping structure
                if(next_node == loop_check_node) {
                    if(next_node != no_node) {
                        positions.add(next_node.position);
                    }

                    finished = true;
                }
            }
        }

        return positions;
    }
}
