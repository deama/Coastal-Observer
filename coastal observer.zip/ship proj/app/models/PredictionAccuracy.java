package models;

/**
 * Created by Christopher Millar on 07/02/2017.
 *
 * The class calculates the accuracy of a prediction
 * using the real longitude/latitude and comparing
 * between the predicted latitude/longitude.
 * This comparison is then used to determine if the
 * prediction is a suitable prediction.
 */
class PredictionAccuracy {

    static void calculateDistance(double latitudeReal, double longitudeReal, double latitudePrediction, double longitudePrediction, double sizeW){
        int R = 6371; // radius of the Earth in metres

        //conversion from degrees to radians
        double x1 = Math.toRadians(longitudeReal); //real longitude in radians
        double x2 = Math.toRadians(longitudePrediction); //predicted longitude in radians
        double y1 = Math.toRadians(latitudeReal); //real latitude in radians
        double y2 = Math.toRadians(latitudePrediction); //predicted latitude in radians

        //difference bewteen the real latitude/predicted latitude
        //differnece between the real longitude/predicted longitude
        double differenceLatitude = (y2-y1);
        double differenceLongitude = (x2-x1);

        //calculate the distance between the real and predicted latitude/longitude; output in metres
        double a = Math.sin(differenceLatitude/2) * Math.sin(differenceLatitude/2) + Math.cos(y1) * Math.cos(y2) *
                Math.sin(differenceLongitude/2) * Math.sin(differenceLongitude/2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        double distance = (double) Math.round(R*c * 10000d) / 10d; // distance output in metres

        double radius = sizeW/2; //radius of the ship

        System.out.println(distance + ": metres");

        //double area = 3.142 * radius * radius;
        //System.out.println(area + " meters^2 ");

        //Check if the prediction was accurate
        //Boolean state true or false would be beneficial?
        if(radius + radius > distance) {
            System.out.println("They Intersect");
        }
        else{
            System.out.print("No intersect");
        }

    }
    public static void main(String[] args){

        double latitudeReal = 51.05412;
        double longitudeReal = 1.65372;
        double latitudePrediction = 51.05394;
        double longitudePrediction = 1.65354;
        double sizeW = 30.0;

        calculateDistance(latitudeReal,longitudeReal,latitudePrediction,longitudePrediction,sizeW);
    }
}
