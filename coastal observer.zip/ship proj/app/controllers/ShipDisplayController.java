package controllers;

import actors.UserActor;
import akka.NotUsed;
import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.actor.Status;
import akka.japi.Pair;
import akka.stream.Materializer;
import akka.stream.OverflowStrategy;
import akka.stream.javadsl.*;
import com.fasterxml.jackson.databind.JsonNode;
import models.ShipStateTrail;
import models.ShipTracker;
import org.reactivestreams.Publisher;
import play.Logger;
import play.libs.F.Either;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import play.mvc.WebSocket;
import views.html.index;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;

/**
 * Created by mr450 on 31/10/2016.
 *
 */
@Singleton
public class ShipDisplayController extends Controller {

    private final ActorSystem actor_system;
    private final Materializer materializer;
    private final ShipTracker ship_tracker;
    private final UserManager user_manager;

    @Inject
    public ShipDisplayController(ActorSystem actor_system, Materializer materializer, ShipTracker ship_tracker, UserManager user_manager) {
        this.actor_system = actor_system;
        this.materializer = materializer;
        this.ship_tracker = ship_tracker;
        this.user_manager = user_manager;
    }

    public WebSocket webSocket() {
        return WebSocket.Json.acceptOrResult(request -> {
            String identifier = String.valueOf(request._underlyingHeader().id());

            final Source<JsonNode, ActorRef> source = Source.actorRef(10, OverflowStrategy.dropTail()); // Input to client
            final Sink<JsonNode, Publisher<JsonNode>> sink = Sink.asPublisher(AsPublisher.WITHOUT_FANOUT); // Output from client

            // Create a pair with materialized values
            final Pair<ActorRef, Publisher<JsonNode>> pair = source.toMat(sink, Keep.both()).run(materializer);
            // Actor (client) will now use ActorRef from Source to send
            final ActorRef user = actor_system.actorOf(Props.create(UserActor.class, identifier, pair.first())); // Create actor

            // Use this sink to receive data. Actor (client) is sent any messages
            final Sink<JsonNode, NotUsed> sink_in = Sink.actorRef(user, new Status.Success("success")); // Attach actor to sink

            final CompletionStage<Flow<JsonNode, JsonNode, NotUsed>> future = CompletableFuture.supplyAsync(() -> {
                final Flow<JsonNode, JsonNode, NotUsed> flow = Flow.fromSinkAndSource(sink_in, Source.fromPublisher(pair.second()));

                return flow.watchTermination((ignore, termination) -> {
                    termination.whenComplete((done, throwable) -> {
                        actor_system.stop(user);
                        user_manager.remove(identifier);
                    });

                    return NotUsed.getInstance();
                });
            });

            user_manager.add(identifier, user);

            return future.thenApplyAsync(Either::Right);
        });
    }

    public Result index() {
        Result result;

        try {
            int ship_count = ship_tracker.getShipCount().get();
            result = ok(index.render("There are " + Integer.toString(ship_count) + " ships."));
        } catch (ExecutionException | InterruptedException ignored) {
            result = internalServerError(index.render("Error cannot get ship count."));
        }

        return result;
    }

    public Result getShipStates() {
        Result result;

        try {
            Map<Integer, ShipStateTrail> ship_data = ship_tracker.getTrailShipStates().get();
            JsonNode json = Json.toJson(ship_data);
            result = ok(json);
        } catch (ExecutionException | InterruptedException ex) {
            Logger.error("ShipDisplayController::getShipStates", ex);
            result = internalServerError(index.render("Error cannot get ship states."));
        }

        return result;
    }
}
