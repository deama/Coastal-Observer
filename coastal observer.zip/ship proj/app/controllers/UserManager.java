package controllers;

import akka.actor.ActorRef;
import com.fasterxml.jackson.databind.JsonNode;
import play.Logger;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by mr450 on 27/11/2016.
 *
 */
public class UserManager {
    private Map<String, ActorRef> users;

    public UserManager() {
        users = new HashMap<>();
    }

    public void publish(JsonNode json_data) {
        for(Map.Entry<String, ActorRef> user : users.entrySet()) {
            user.getValue().tell(json_data, ActorRef.noSender());
        }
    }

    public void add(String identifier, ActorRef user) {
        users.put(identifier, user);
        Logger.debug("New user connected.");
    }

    public void remove(String identifier) {
        users.remove(identifier);
        Logger.debug("User disconnected. Total user count is now {}.", users.size());
    }
}
