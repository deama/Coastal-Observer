package services;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;

import javax.inject.*;
import play.Environment;

/**
 * Created by mr450 on 31/10/2016.
 *
 */
public class AisVdmSource {

    private HashMap<String, String> paths;

    @Inject
    public AisVdmSource(Environment environment) throws FileNotFoundException {
        paths = new HashMap<>();
        String path_prefix = "conf/resources";
        File data_directory = environment.getFile(path_prefix);
        File[] files = data_directory.listFiles();

        if(files == null) {
            throw new FileNotFoundException("Could not open the directory \"" + path_prefix + "\".");
        }

        for(File file : files) {
            if(file.isFile()) {
                paths.put(file.getName(), file.getAbsolutePath());
            }
        }
    }

    public String getCsvFilePath(String name) {
        return paths.get(name);
    }
}
