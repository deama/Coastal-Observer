package utils;

import play.Logger;

import javax.annotation.Nonnull;
import java.util.concurrent.ThreadFactory;

/**
 * Created by mr450 on 16/11/2016.
 *
 */
public class ListenableThreadFactory implements ThreadFactory {

    @Override
    public Thread newThread(@Nonnull Runnable runnable) {
        final Thread thread = new Thread(runnable);
        thread.setUncaughtExceptionHandler((t, ex) -> Logger.error("ExecutorService's ThreadFactory Uncaught:", ex));
        return thread;
    }
}
