package utils;

import java.util.AbstractList;
import java.util.Iterator;

/**
 * Created by mr450 on 04/11/2016.
 *
 */
public class CircularListDecorator<E> extends AbstractList<E> {
    private final AbstractList<E> list;
    private final int max_elements;
    private int list_index;
    private int head_element;
    private int tail_element;

    /**
     *
     * @param list
     * @param max_elements
     */
    public CircularListDecorator(AbstractList<E> list, int max_elements) {
        this.list = list;
        this.max_elements = max_elements;
        list_index = 0;
        head_element = 0;
        tail_element = 0;
    }

    /**
     *
     * @param index
     * @return
     */
    @Override
    public E get(int index) {
        return list.get(index);
    }

    /**
     *
     * @param element
     * @return
     */
    @Override
    public boolean add(E element) {
        int index = list_index % max_elements;

        // Store index for head to avoid
        // Out-of-bounds
        head_element = index;

        E previous;
        boolean result;

        if(list.size() == max_elements) {
            previous = list.set(index, element);
            result = previous != element;
            tail_element = (tail_element + 1) % max_elements;
        } else {
            result = list.add(element);
        }

        list_index++;

        return result;
    }

    /**
     *
     * @return
     */
    @Override
    public int size() {
        return list.size();
    }

    /**
     *
     *
     */
    public int getMaxElements() {
        return max_elements;
    }

    /**
     *
     * @return
     */
    public E getLastElement() {
        return list.get(head_element);
    }

    /**
     *
     * @return
     */
    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            private int index = tail_element;
            private boolean end_flag = true;

            @Override
            public boolean hasNext() {
                return end_flag && index < list.size();
            }

            @Override
            public E next() {
                E element = list.get(index);
                index = (index + 1) % max_elements;
                end_flag = !(index == tail_element);

                return element;
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }
}
