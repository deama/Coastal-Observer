/**
 * Created by mr450 on 13/03/2017.
 *
 */
import org.junit.Test;
import utils.CircularListDecorator;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

/**
 * Created by mr450 on 22/01/2017.
 *
 */
public class TestPredict {

    @Test
    public void testSimplePredict() {
        double latitude = 51.10295;
        double longitude = 1.39433;
        double[] sog = {0};
        double[] heading = {0};
        int depth = 0;
        CircularListDecorator<Integer> decorator = new CircularListDecorator<>(list, 5);
        decorator.add(1);
        assertEquals(new Integer(1), decorator.get(0));
    }
}
