import java.util.LinkedList;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.junit.*;

import static models.CsvNmeaProducer.Exit.*;
import static org.junit.Assert.*;

import models.NmeaMessage;
import models.CsvNmeaProducer;
import models.MessageProcessorInterface;

/**
 * Created by mr450 on 03/11/2016.
 *
 */
public class TestNmeaProducer {
    private static class Callback implements MessageProcessorInterface {
        LinkedList<NmeaMessage> messages;

        Callback() {
            messages = new LinkedList<>();
        }

        @Override
        public void reset() {}

        @Override
        public void update(NmeaMessage message) {
            messages.add(message);
        }

        @Override
        public void updatePrediction(NmeaMessage message) {}
    }

    private static LinkedList<CSVRecord> createCsvRecords(LinkedList<String> csv_strings) throws java.io.IOException {
        LinkedList<CSVRecord> records = new LinkedList<>();

        for (String csv_string : csv_strings) {
            records.add(CSVParser.parse(csv_string, CSVFormat.DEFAULT).getRecords().get(0));
        }

        return records;
    }

    private static boolean testCsvProducer(LinkedList<CSVRecord> records, LinkedList<NmeaMessage> list_to_fill, int expected_size) {
        int initial_size = list_to_fill.size();

        Callback callback = new Callback();
        CsvNmeaProducer producer = new CsvNmeaProducer(records, callback, ON_READ_ALL);
        producer.fill(0, records.size(), list_to_fill);
        assertEquals(expected_size, list_to_fill.size());

        return list_to_fill.size() != initial_size;
    }

    @Test
    public void testValidNmea() throws java.io.IOException {
        LinkedList<String> csv_strings = new LinkedList<>();
        csv_strings.add("!AIVDM,1,1,,A,169:G9?P12`V`40EQkVlnOvL081N,0*4B");
        csv_strings.add("!AIVDM,1,1,,A,19NS9jh01O0D2=pOQDDem:rJ0<0;,0*5E");
        LinkedList<CSVRecord> records = createCsvRecords(csv_strings);

        LinkedList<NmeaMessage> list_to_fill = new LinkedList<>();

        assertEquals(true, testCsvProducer(records, list_to_fill, 2));
    }

    @Test
    public void testInvalidFragmentNmea() throws java.io.IOException {
        LinkedList<String> csv_strings = new LinkedList<>();
        csv_strings.add("!AIVDM,0,0,,A,133i`mPP000CjiPMcwk1Mgwd089F,0*1E");
        csv_strings.add("!AIVDM,1,3,,A,19NS9jh01O0D2=pOQDDem:rJ0<0;,0*5E");
        LinkedList<CSVRecord> records = createCsvRecords(csv_strings);

        LinkedList<NmeaMessage> list_to_fill = new LinkedList<>();

        assertEquals(false, testCsvProducer(records, list_to_fill, 0));
    }

    @Test
    public void testInvalidPayloadNmea() throws java.io.IOException {
        LinkedList<String> csv_strings = new LinkedList<>();
        csv_strings.add("!AIVDM,1,1,,A,A_Broken_Payload,0*1E");
        csv_strings.add("!AIVDM,1,1,,A,__,0*5E");
        csv_strings.add("!AIVDM,1,1,,A,...................................12334),0*5E");
        LinkedList<CSVRecord> records = createCsvRecords(csv_strings);

        LinkedList<NmeaMessage> list_to_fill = new LinkedList<>();

        assertEquals(false, testCsvProducer(records, list_to_fill, 0));
    }

    @Test
    public void testInvalidIdentifierNmea() throws java.io.IOException {
        LinkedList<String> csv_strings = new LinkedList<>();
        csv_strings.add("1,1,,A,169:G9?P12`V`40EQkVlnOvL081N,0*4B");
        csv_strings.add("!aivdm,1,1,,A,19NS9jh01O0D2=pOQDDem:rJ0<0;,0*5E");
        LinkedList<CSVRecord> records = createCsvRecords(csv_strings);
        LinkedList<NmeaMessage> list_to_fill = new LinkedList<>();

        assertEquals(false, testCsvProducer(records, list_to_fill, 0));
    }

    @Test
    public void testReadNextMessage() throws java.io.IOException {
        LinkedList<String> csv_strings = new LinkedList<>();
        csv_strings.add("!AIVDM,1,1,,A,169:G9?P12`V`40EQkVlnOvL081N,0*4B");
        csv_strings.add("!AIVDM,1,1,,A,19NS9jh01O0D2=pOQDDem:rJ0<0;,0*5E");
        LinkedList<CSVRecord> records = createCsvRecords(csv_strings);

        Callback callback = new Callback();
        CsvNmeaProducer producer = new CsvNmeaProducer(records, callback, ON_READ_ALL);
        producer.getMessageData();

        assertEquals(2, callback.messages.size());
    }

    @Test
    public void testInvalidReadNextMessage() throws java.io.IOException {
        LinkedList<String> csv_strings = new LinkedList<>();
        csv_strings.add("1,1,,A,169:G9?P12`V`40EQkVlnOvL081N,0*4B");
        csv_strings.add("!aivdm,1,1,,A,19NS9jh01O0D2=pOQDDem:rJ0<0;,0*5E");
        LinkedList<CSVRecord> records = createCsvRecords(csv_strings);

        Callback callback = new Callback();
        CsvNmeaProducer producer = new CsvNmeaProducer(records, callback, ON_READ_ALL);
        producer.getMessageData();

        assertEquals(0, callback.messages.size());
    }
}
