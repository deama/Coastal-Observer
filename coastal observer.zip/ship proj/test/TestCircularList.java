import org.junit.Test;
import utils.CircularListDecorator;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

/**
 * Created by mr450 on 22/01/2017.
 *
 */
public class TestCircularList {

    @Test
    public void testSimpleAdd() {
        ArrayList<Integer> list = new ArrayList<>();
        CircularListDecorator<Integer> decorator = new CircularListDecorator<>(list, 5);
        decorator.add(1);
        assertEquals(new Integer(1), decorator.get(0));
    }

    @Test
    public void testComplexAdd() {
        ArrayList<Integer> list = new ArrayList<>();
        CircularListDecorator<Integer> decorator = new CircularListDecorator<>(list, 4);
        decorator.add(1);
        decorator.add(2);
        decorator.add(3);
        decorator.add(4);
        assertEquals(new Integer(4), decorator.get(3));
        decorator.add(5); // Replaces "1" with "5"
        assertEquals(new Integer(5), decorator.get(0));
    }

    @Test
    public void testSimpleIteration() {
        ArrayList<Integer> list = new ArrayList<>();
        CircularListDecorator<Integer> decorator = new CircularListDecorator<>(list, 4);
        decorator.add(1);
        decorator.add(2);
        decorator.add(3);
        decorator.add(4);
        Integer count = 1;

        for(Integer number : decorator) {
            assertEquals(count, number);
            count++;
        }
    }

    @Test
    public void testComplexIteration() {
        ArrayList<Integer> list = new ArrayList<>();
        CircularListDecorator<Integer> decorator = new CircularListDecorator<>(list, 4);
        decorator.add(1);
        decorator.add(2);
        decorator.add(3);
        decorator.add(4);
        decorator.add(5);

        // "1" is replaced with "5"
        // Iteration now starts at new tail
        // which has value "2"
        Integer count = 2;

        for(Integer number : decorator) {
            assertEquals(count, number);
            count++;
        }

        // Ensure it has iterated through all values
        assertEquals(new Integer(6), count);
    }

    @Test
    public void testSingleValueIteration() {
        ArrayList<Integer> list = new ArrayList<>();
        CircularListDecorator<Integer> decorator = new CircularListDecorator<>(list, 4);
        decorator.add(55);

        for(Integer number : decorator) {
            assertEquals(new Integer(55), number);
        }
    }
}
